#!/usr/bin/env bash
#
# Start the POC: one OPA server, one application.
#
#   ./run.sh            start both, serve on http://localhost:8000
#   ./run.sh test       run the policy tests and the end-to-end tests
#
# OPA is fetched for this machine's platform on first run rather than being
# committed as a binary, so the repo works on macOS, Linux and CI alike.

set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

OPA_BIN="${OPA_PATH:-$ROOT/bin/opa}"
APP_PORT="${APP_PORT:-8000}"
OPA_PORT="${OPA_PORT:-8181}"
OPA_VERSION="${OPA_VERSION:-latest}"

log() { printf '\033[36m==>\033[0m %s\n' "$*"; }
err() { printf '\033[31m!!\033[0m %s\n' "$*" >&2; }

# --- OPA ---------------------------------------------------------------------

detect_opa_asset() {
  local os arch
  os="$(uname -s | tr '[:upper:]' '[:lower:]')"
  arch="$(uname -m)"
  case "$arch" in
    x86_64|amd64) arch="amd64" ;;
    arm64|aarch64) arch="arm64" ;;
    *) err "unsupported architecture: $arch"; return 1 ;;
  esac
  case "$os" in
    darwin) echo "opa_darwin_${arch}" ;;
    linux)  echo "opa_linux_${arch}_static" ;;
    *) err "unsupported OS: $os"; return 1 ;;
  esac
}

ensure_opa() {
  if command -v opa >/dev/null 2>&1 && [[ ! -x "$OPA_BIN" ]]; then
    OPA_BIN="$(command -v opa)"
  fi
  if [[ -x "$OPA_BIN" ]]; then
    return
  fi

  local asset url
  asset="$(detect_opa_asset)"
  if [[ "$OPA_VERSION" == "latest" ]]; then
    url="https://github.com/open-policy-agent/opa/releases/latest/download/${asset}"
  else
    url="https://github.com/open-policy-agent/opa/releases/download/${OPA_VERSION}/${asset}"
  fi

  log "downloading OPA ($asset)"
  mkdir -p "$ROOT/bin"
  curl -sSL --fail -o "$OPA_BIN" "$url"
  chmod +x "$OPA_BIN"
}

start_opa() {
  if curl -sf "http://localhost:${OPA_PORT}/health" >/dev/null 2>&1; then
    log "OPA already running on :${OPA_PORT}"
    return
  fi
  log "starting OPA on :${OPA_PORT}"
  "$OPA_BIN" run --server --addr "localhost:${OPA_PORT}" --log-level error &
  OPA_PID=$!
  for _ in $(seq 1 30); do
    curl -sf "http://localhost:${OPA_PORT}/health" >/dev/null 2>&1 && return
    sleep 0.3
  done
  err "OPA did not become healthy"
  exit 1
}

cleanup() {
  [[ -n "${OPA_PID:-}" ]] && kill "$OPA_PID" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

# --- commands ----------------------------------------------------------------

if [[ "${1:-serve}" == "test" ]]; then
  ensure_opa
  log "policy tests"
  "$OPA_BIN" test policy/ -v
  start_opa
  log "end-to-end tests"
  OPA_PORT="$OPA_PORT" python3 -m unittest discover -s tests -t . -v
  exit 0
fi

ensure_opa
start_opa

log "serving on http://localhost:${APP_PORT}"
log "  management UI    http://localhost:${APP_PORT}/"
log "  runtime console  http://localhost:${APP_PORT}/runtime"
exec python3 -m uvicorn app.main:app --host 0.0.0.0 --port "${APP_PORT}"
