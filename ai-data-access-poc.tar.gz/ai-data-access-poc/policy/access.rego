# =============================================================================
# AI-ready data access — unified access policy
#
# This package is the single decision point for the policy gateway. It merges
# two policy families that previously lived in separate prototypes:
#
#   from opa_demo    : data residency, PII processing, processing purpose
#   from Proven-Data : restricted jurisdictions, Luxembourg banking secrecy,
#                      privacy lawful basis / retention
#
# Input contract (assembled by the gateway from the five registries):
#
#   input.agent     - agent registry entry
#   input.use_case  - use-case registry entry
#   input.service   - MCP / tool registry entry
#   input.dataset   - data catalogue entry
#   input.policy    - policy rule registry entry
#
# Fail closed: allow_access defaults to false, and every dimension that depends
# on policy-registry configuration explicitly requires that configuration to be
# present rather than passing vacuously when it is missing.
# =============================================================================

package poc.access

import rego.v1

# The policy declares its own version. The gateway reports whatever comes back
# here, so audit evidence can never attest to a version that is not loaded.
policy_version := "poc.access/v2.1.0"

default allow_access := false

allow_access if {
	ai_access_pass
	data_residency_pass
	pii_processing_pass
	processing_purpose_pass
	jurisdiction_sanction_pass
	banking_secrecy_pass
	privacy_lawful_basis_pass
}

# -----------------------------------------------------------------------------
# Safe accessors — keep explanation strings defined even for malformed input
# -----------------------------------------------------------------------------

agent_location := object.get(input, ["agent", "processing_location"], "unknown")

agent_pii_cleared := object.get(input, ["agent", "can_process_pii"], false)

service_jurisdiction := object.get(input, ["service", "jurisdiction"], "unknown")

service_purposes := object.get(input, ["service", "permitted_processing_purposes"], [])

dataset_jurisdiction := object.get(input, ["dataset", "data_jurisdiction"], "unknown")

dataset_pii_class := object.get(input, ["dataset", "pii_classification"], "unknown")

use_case_purpose := object.get(input, ["use_case", "purpose"], "unknown")

use_case_regions := object.get(input, ["use_case", "data_regions"], [])

# Policy-registry lists are hoisted through object.get so that a missing policy
# registry yields null rather than an undefined expression. Negating a builtin
# call over an undefined path is itself undefined in Rego, which would silently
# drop the fail-closed explanation strings below.
restricted_list := object.get(input, ["policy", "restricted_jurisdictions"], null)

secrecy_list := object.get(input, ["policy", "banking_secrecy_jurisdictions"], null)

# -----------------------------------------------------------------------------
# 0. AI access permission
#    The data owner records, per dataset, whether AI agents may consume it at
#    all. This is the coarsest gate and is evaluated first.
# -----------------------------------------------------------------------------

ai_access_pass if input.dataset.ai_access_permitted == true

ai_access_status := "PASSED" if ai_access_pass

ai_access_status := "FAILED" if not ai_access_pass

ai_access_reason := "Data owner permits AI agent access to this dataset." if ai_access_pass

ai_access_reason := sprintf(
	"Data owner has not permitted AI agent access to dataset '%v'.",
	[object.get(input, ["dataset", "id"], "unknown")],
) if not ai_access_pass

# -----------------------------------------------------------------------------
# 1. Data residency
#    The agent's processing location must match both the serving MCP server's
#    jurisdiction and the jurisdiction the data itself resides in.
# -----------------------------------------------------------------------------

data_residency_pass if {
	input.agent.processing_location == input.service.jurisdiction
	input.agent.processing_location == input.dataset.data_jurisdiction
}

data_residency_status := "PASSED" if data_residency_pass

data_residency_status := "FAILED" if not data_residency_pass

data_residency_reason := sprintf(
	"Agent processes in %v; MCP server jurisdiction %v; data residency %v — aligned.",
	[agent_location, service_jurisdiction, dataset_jurisdiction],
) if data_residency_pass

data_residency_reason := sprintf(
	"Jurisdiction mismatch: agent processes in %v but MCP server is %v and data resides in %v.",
	[agent_location, service_jurisdiction, dataset_jurisdiction],
) if not data_residency_pass

# -----------------------------------------------------------------------------
# 2. PII processing
#    Non-PII passes regardless of clearance. Restricted PII requires the agent
#    to hold explicit clearance. Any unrecognised classification denies.
# -----------------------------------------------------------------------------

pii_clearance_valid(class, _) if class == "none"

pii_clearance_valid(class, cleared) if {
	class == "restricted_pii"
	cleared == true
}

pii_processing_pass if {
	pii_clearance_valid(input.dataset.pii_classification, input.agent.can_process_pii)
}

pii_processing_status := "PASSED" if pii_processing_pass

pii_processing_status := "FAILED" if not pii_processing_pass

pii_processing_reason := sprintf(
	"Dataset PII classification '%v' is satisfied by the agent's clearance.",
	[dataset_pii_class],
) if pii_processing_pass

pii_processing_reason := sprintf(
	"Dataset is classified '%v' and agent PII clearance is %v — processing not permitted.",
	[dataset_pii_class, agent_pii_cleared],
) if not pii_processing_pass

# -----------------------------------------------------------------------------
# 3. Processing purpose
#    The use case's declared purpose must be one the MCP server permits.
# -----------------------------------------------------------------------------

processing_purpose_pass if {
	some permitted in input.service.permitted_processing_purposes
	permitted == input.use_case.purpose
}

processing_purpose_status := "PASSED" if processing_purpose_pass

processing_purpose_status := "FAILED" if not processing_purpose_pass

processing_purpose_reason := sprintf(
	"Use-case purpose '%v' is listed in the server's permitted purposes %v.",
	[use_case_purpose, service_purposes],
) if processing_purpose_pass

processing_purpose_reason := sprintf(
	"Use-case purpose '%v' is not among the server's permitted purposes %v.",
	[use_case_purpose, service_purposes],
) if not processing_purpose_pass

# -----------------------------------------------------------------------------
# 4. Restricted jurisdictions
#    Every jurisdiction implicated by the request — the regions the use case
#    declares, the data's own residency, and the serving MCP server's location
#    — is checked against the policy registry's restricted list.
#
#    This is the dimension the POC's second demo scenario exercises: the
#    use-case team updates its metadata to analyse data residing in a
#    restricted region, and the same agent running the same prompt is denied.
# -----------------------------------------------------------------------------

requested_jurisdictions contains j if some j in use_case_regions

requested_jurisdictions contains j if {
	j := input.dataset.data_jurisdiction
	j != null
}

requested_jurisdictions contains j if {
	j := input.service.jurisdiction
	j != null
}

restricted_hits contains j if {
	some j in requested_jurisdictions
	j in restricted_list
}

jurisdiction_sanction_pass if {
	# Fail closed when the policy registry has not supplied a restricted list.
	is_array(restricted_list)
	count(restricted_hits) == 0
}

jurisdiction_sanction_status := "PASSED" if jurisdiction_sanction_pass

jurisdiction_sanction_status := "FAILED" if not jurisdiction_sanction_pass

jurisdiction_sanction_reason := "No restricted jurisdiction is implicated by this request." if jurisdiction_sanction_pass

jurisdiction_sanction_reason := sprintf(
	"Request implicates restricted jurisdiction(s) %v — access is blocked by policy.",
	[sort(restricted_hits)],
) if count(restricted_hits) > 0

jurisdiction_sanction_reason := "Policy registry did not supply a restricted-jurisdiction list — failing closed." if not is_array(restricted_list)

# -----------------------------------------------------------------------------
# 5. Banking secrecy
#    In a banking-secrecy jurisdiction, releasing client-identifying data under
#    a true identity requires specialist review unless access is restricted to
#    that jurisdiction's own employees.
# -----------------------------------------------------------------------------

secrecy_in_scope if {
	input.dataset.data_jurisdiction in secrecy_list
	input.dataset.contains_client_data == true
	input.dataset.identity_type == "true_identity"
	not input.dataset.employee_only_access
}

banking_secrecy_pass if {
	is_array(secrecy_list)
	not secrecy_in_scope
}

banking_secrecy_status := "PASSED" if banking_secrecy_pass

banking_secrecy_status := "FAILED" if not banking_secrecy_pass

banking_secrecy_reason := "No banking secrecy restriction applies to this dataset." if banking_secrecy_pass

banking_secrecy_reason := sprintf(
	"%v banking secrecy: dataset exposes client identity and access is not employee-only — specialist review required.",
	[dataset_jurisdiction],
) if secrecy_in_scope

banking_secrecy_reason := "Policy registry did not supply a banking-secrecy jurisdiction list — failing closed." if not is_array(secrecy_list)

# -----------------------------------------------------------------------------
# 6. Privacy lawful basis
#    Personal data in a banking-secrecy jurisdiction needs both a recorded
#    lawful basis and a retention period on the use case.
#
#    trim_space is used deliberately: whitespace-only metadata is treated as
#    absent, so the policy cannot be satisfied by a blank-looking value.
# -----------------------------------------------------------------------------

privacy_gap if {
	privacy_in_scope
	trim_space(object.get(input, ["use_case", "lawful_basis"], "")) == ""
}

privacy_gap if {
	privacy_in_scope
	trim_space(object.get(input, ["use_case", "retention_period"], "")) == ""
}

privacy_in_scope if {
	input.dataset.data_jurisdiction in secrecy_list
	input.dataset.pii_classification == "restricted_pii"
	not input.dataset.employee_only_access
}

privacy_lawful_basis_pass if {
	is_array(secrecy_list)
	not privacy_gap
}

privacy_lawful_basis_status := "PASSED" if privacy_lawful_basis_pass

privacy_lawful_basis_status := "FAILED" if not privacy_lawful_basis_pass

privacy_lawful_basis_reason := "Lawful basis and retention period are recorded, or are not required here." if privacy_lawful_basis_pass

privacy_lawful_basis_reason := sprintf(
	"%v privacy: personal data requires a recorded lawful basis and retention period on the use case.",
	[dataset_jurisdiction],
) if privacy_gap

privacy_lawful_basis_reason := "Policy registry did not supply a banking-secrecy jurisdiction list — failing closed." if not is_array(secrecy_list)

# -----------------------------------------------------------------------------
# Proportionate controls and approval routing (Proven-Data lineage)
# -----------------------------------------------------------------------------

controls contains "Audit logging"

controls contains "Purpose limitation"

controls contains "Non-PII data only" if input.dataset.pii_classification == "none"

controls contains "Internal identifiers only" if input.dataset.identity_type == "internal_ids_only"

controls contains "Employee-only access" if input.dataset.employee_only_access == true

controls contains "Cross-border scope review" if not data_residency_pass

controls contains "PII clearance uplift" if not pii_processing_pass

controls contains "Banking secrecy assessment" if secrecy_in_scope

controls contains "Privacy assessment" if privacy_gap

controls contains "Restricted jurisdiction block" if count(restricted_hits) > 0

controls contains "AI access entitlement required" if not ai_access_pass

approval_path := "Blocked — restricted jurisdiction" if {
	count(restricted_hits) > 0
} else := "Enhanced banking secrecy review" if {
	secrecy_in_scope
} else := "Focused privacy review" if {
	privacy_gap
} else := "Enhanced cross-border review" if {
	not data_residency_pass
} else := "PII clearance uplift required" if {
	not pii_processing_pass
} else := "Purpose re-scoping required" if {
	not processing_purpose_pass
} else := "Data owner AI-access entitlement required" if {
	not ai_access_pass
} else := "Existing entitlement / proportionate approval"

# -----------------------------------------------------------------------------
# Explainable decision metadata — rendered directly by the runtime console
# -----------------------------------------------------------------------------

overall_status := "ALLOWED" if allow_access

overall_status := "DENIED" if not allow_access

overall_reason := "Access authorised: all business policy requirements are satisfied." if allow_access

overall_reason := "Access denied: one or more business policies failed validation." if not allow_access

decision_metadata := {
	"ai_access": {"status": ai_access_status, "reason": ai_access_reason},
	"data_residency": {"status": data_residency_status, "reason": data_residency_reason},
	"pii_processing": {"status": pii_processing_status, "reason": pii_processing_reason},
	"processing_purpose": {"status": processing_purpose_status, "reason": processing_purpose_reason},
	"jurisdiction_sanction": {"status": jurisdiction_sanction_status, "reason": jurisdiction_sanction_reason},
	"banking_secrecy": {"status": banking_secrecy_status, "reason": banking_secrecy_reason},
	"privacy_lawful_basis": {"status": privacy_lawful_basis_status, "reason": privacy_lawful_basis_reason},
	"overall": {"status": overall_status, "reason": overall_reason},
}

# The single object the gateway reads.
decision := {
	"allow_access": allow_access,
	"policy_version": policy_version,
	"decision_metadata": decision_metadata,
	"controls": sort(controls),
	"approval_path": approval_path,
}
