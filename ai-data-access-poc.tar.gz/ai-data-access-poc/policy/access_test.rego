# =============================================================================
# Policy unit tests — run with:  opa test policy/ -v
#
# These exercise the Rego itself against realistic registry records. Neither
# source prototype tested its policy; this closes that gap.
# =============================================================================

package poc.access_test

import data.poc.access
import rego.v1

# -----------------------------------------------------------------------------
# Fixtures mirroring the seeded registries
# -----------------------------------------------------------------------------

policy_rules := {
	"restricted_jurisdictions": ["Iran", "North Korea", "Syria"],
	"banking_secrecy_jurisdictions": ["Luxembourg"],
}

uk_agent := {
	"id": "briefing_agent_01",
	"processing_location": "UK",
	"can_process_pii": false,
}

cleared_agent := object.union(uk_agent, {"can_process_pii": true})

uk_use_case := {
	"id": "uc_credit_briefing",
	"purpose": "client_briefing",
	"data_regions": ["UK"],
	"lawful_basis": "Legitimate interest - credit risk management",
	"retention_period": "12 months",
}

uk_service := {
	"id": "corporate_aggregate_mcp",
	"jurisdiction": "UK",
	"permitted_processing_purposes": ["client_briefing", "risk_evaluation"],
}

us_service := object.union(uk_service, {"id": "us_corporate_mcp", "jurisdiction": "US"})

lux_service := object.union(uk_service, {"id": "lux_client_mcp", "jurisdiction": "Luxembourg"})

aggregate_dataset := {
	"id": "ds_aggregate_exposure",
	"data_jurisdiction": "UK",
	"pii_classification": "none",
	"contains_client_data": false,
	"identity_type": "not_applicable",
	"ai_access_permitted": true,
}

pii_dataset := {
	"id": "ds_client_pii_exposure",
	"data_jurisdiction": "UK",
	"pii_classification": "restricted_pii",
	"contains_client_data": true,
	"identity_type": "true_identity",
	"ai_access_permitted": true,
}

us_dataset := object.union(aggregate_dataset, {"id": "ds_us_exposure", "data_jurisdiction": "US"})

lux_dataset := {
	"id": "ds_lux_client_exposure",
	"data_jurisdiction": "Luxembourg",
	"pii_classification": "restricted_pii",
	"contains_client_data": true,
	"identity_type": "true_identity",
	"employee_only_access": false,
	"ai_access_permitted": true,
}

request(agent, use_case, service, dataset) := {
	"agent": agent,
	"use_case": use_case,
	"service": service,
	"dataset": dataset,
	"policy": policy_rules,
}

# -----------------------------------------------------------------------------
# Happy path
# -----------------------------------------------------------------------------

test_aggregate_request_is_allowed if {
	result := access.decision with input as request(uk_agent, uk_use_case, uk_service, aggregate_dataset)
	result.allow_access
	result.decision_metadata.overall.status == "ALLOWED"
	result.approval_path == "Existing entitlement / proportionate approval"
}

test_allowed_request_reports_every_dimension_passed if {
	meta := access.decision_metadata with input as request(uk_agent, uk_use_case, uk_service, aggregate_dataset)
	every dimension in [
		"ai_access", "data_residency", "pii_processing", "processing_purpose",
		"jurisdiction_sanction", "banking_secrecy", "privacy_lawful_basis",
	] {
		meta[dimension].status == "PASSED"
	}
}

# -----------------------------------------------------------------------------
# PII processing
# -----------------------------------------------------------------------------

test_restricted_pii_denied_without_clearance if {
	result := access.decision with input as request(uk_agent, uk_use_case, uk_service, pii_dataset)
	not result.allow_access
	result.decision_metadata.pii_processing.status == "FAILED"
	result.approval_path == "PII clearance uplift required"
}

test_restricted_pii_allowed_with_clearance if {
	result := access.decision with input as request(cleared_agent, uk_use_case, uk_service, pii_dataset)
	result.allow_access
}

test_unknown_pii_classification_denies if {
	odd := object.union(aggregate_dataset, {"pii_classification": "something_new"})
	result := access.decision with input as request(cleared_agent, uk_use_case, uk_service, odd)
	not result.allow_access
	result.decision_metadata.pii_processing.status == "FAILED"
}

# -----------------------------------------------------------------------------
# Data residency
# -----------------------------------------------------------------------------

test_cross_border_request_denied_on_residency if {
	result := access.decision with input as request(uk_agent, uk_use_case, us_service, us_dataset)
	not result.allow_access
	result.decision_metadata.data_residency.status == "FAILED"
}

# -----------------------------------------------------------------------------
# Processing purpose
# -----------------------------------------------------------------------------

test_unpermitted_purpose_denied if {
	marketing := object.union(uk_use_case, {"purpose": "marketing_analytics"})
	result := access.decision with input as request(uk_agent, marketing, uk_service, aggregate_dataset)
	not result.allow_access
	result.decision_metadata.processing_purpose.status == "FAILED"
}

# -----------------------------------------------------------------------------
# Restricted jurisdictions — the second POC demo scenario
# -----------------------------------------------------------------------------

test_use_case_targeting_restricted_region_is_denied if {
	changed := object.union(uk_use_case, {"data_regions": ["UK", "Iran"]})
	result := access.decision with input as request(uk_agent, changed, uk_service, aggregate_dataset)
	not result.allow_access
	result.decision_metadata.jurisdiction_sanction.status == "FAILED"
	result.approval_path == "Blocked — restricted jurisdiction"
}

test_same_request_allowed_before_metadata_change if {
	result := access.decision with input as request(uk_agent, uk_use_case, uk_service, aggregate_dataset)
	result.allow_access
}

test_dataset_residing_in_restricted_region_is_denied if {
	iran_dataset := object.union(aggregate_dataset, {"data_jurisdiction": "Iran"})
	iran_service := object.union(uk_service, {"jurisdiction": "Iran"})
	iran_agent := object.union(uk_agent, {"processing_location": "Iran"})
	result := access.decision with input as request(iran_agent, uk_use_case, iran_service, iran_dataset)
	not result.allow_access
	result.decision_metadata.jurisdiction_sanction.status == "FAILED"
}

# -----------------------------------------------------------------------------
# Luxembourg banking secrecy and privacy
# -----------------------------------------------------------------------------

test_luxembourg_client_identity_requires_review if {
	lux_uc := object.union(uk_use_case, {"data_regions": ["Luxembourg"]})
	lux_ag := object.union(cleared_agent, {"processing_location": "Luxembourg"})
	result := access.decision with input as request(lux_ag, lux_uc, lux_service, lux_dataset)
	not result.allow_access
	result.decision_metadata.banking_secrecy.status == "FAILED"
	result.approval_path == "Enhanced banking secrecy review"
}

test_luxembourg_employee_only_access_passes_secrecy if {
	lux_uc := object.union(uk_use_case, {"data_regions": ["Luxembourg"]})
	lux_ag := object.union(cleared_agent, {"processing_location": "Luxembourg"})
	employee_only := object.union(lux_dataset, {"employee_only_access": true})
	meta := access.decision_metadata with input as request(lux_ag, lux_uc, lux_service, employee_only)
	meta.banking_secrecy.status == "PASSED"
}

test_whitespace_only_lawful_basis_is_treated_as_absent if {
	lux_uc := object.union(uk_use_case, {"data_regions": ["Luxembourg"], "lawful_basis": "   "})
	lux_ag := object.union(cleared_agent, {"processing_location": "Luxembourg"})
	internal := object.union(lux_dataset, {"identity_type": "internal_ids_only"})
	meta := access.decision_metadata with input as request(lux_ag, lux_uc, lux_service, internal)
	meta.privacy_lawful_basis.status == "FAILED"
}

test_missing_retention_period_fails_privacy if {
	lux_uc := object.union(uk_use_case, {"data_regions": ["Luxembourg"], "retention_period": ""})
	lux_ag := object.union(cleared_agent, {"processing_location": "Luxembourg"})
	internal := object.union(lux_dataset, {"identity_type": "internal_ids_only"})
	meta := access.decision_metadata with input as request(lux_ag, lux_uc, lux_service, internal)
	meta.privacy_lawful_basis.status == "FAILED"
}

# -----------------------------------------------------------------------------
# Fail-closed behaviour
# -----------------------------------------------------------------------------

test_dataset_closed_to_ai_is_denied if {
	closed := object.union(aggregate_dataset, {"ai_access_permitted": false})
	result := access.decision with input as request(uk_agent, uk_use_case, uk_service, closed)
	not result.allow_access
	result.decision_metadata.ai_access.status == "FAILED"
	result.approval_path == "Data owner AI-access entitlement required"
}

test_empty_input_denies if {
	result := access.decision with input as {}
	not result.allow_access
}

test_missing_service_and_dataset_denies if {
	result := access.decision with input as {
		"agent": uk_agent,
		"use_case": uk_use_case,
		"service": {},
		"dataset": {},
		"policy": policy_rules,
	}
	not result.allow_access
}

test_missing_policy_registry_fails_closed if {
	result := access.decision with input as {
		"agent": uk_agent,
		"use_case": uk_use_case,
		"service": uk_service,
		"dataset": aggregate_dataset,
		"policy": {},
	}
	not result.allow_access
	result.decision_metadata.jurisdiction_sanction.status == "FAILED"
	result.decision_metadata.banking_secrecy.status == "FAILED"
}

test_ai_access_dimension_is_always_reported if {
	meta := access.decision_metadata with input as {}
	meta.ai_access.status == "FAILED"
}

test_decision_always_carries_a_policy_version if {
	result := access.decision with input as {}
	result.policy_version == "poc.access/v2.1.0"
}
