# AI-Ready Data Access — end-to-end POC

A merge of two prototypes into one working system:

- **Proven-Data-v8** contributed the business policy domain — jurisdictions,
  Luxembourg banking secrecy, privacy lawful basis, approval paths, proportionate
  controls.
- **opa_demo** contributed the runtime — an agent, MCP server discovery, an
  enforcement checkpoint, live decision visualisation and a glass-box policy reveal.

Neither had the piece that joins them: **registries that both halves read and
write**. That is what this POC adds, and it is what makes the headline demo work —
change metadata in the UI, and the next agent request is decided differently, with
no change to the agent and no change to the policy.

```
   ┌────────────────────────── one application ──────────────────────────┐
   │  /          Management UI        /runtime   Runtime console         │
   ├─────────────────────────────────────────────────────────────────────┤
   │  registries.py   agent registry · use-case registry · data catalogue│
   │                  MCP/tool registry · policy rule registry           │
   │  gateway.py      the single enforcement point                       │
   │  mcp_server.py   mocked data supplier (payloads only)               │
   │  agent.py        deterministic agent                                │
   │  decision_log.py every decision, keyed by correlation id            │
   │  events.py       SSE fan-out to the console                         │
   └───────────────────────────────┬─────────────────────────────────────┘
                                   │ POST /v1/data/poc/access
                          ┌────────▼────────┐
                          │   OPA server    │  policy/access.rego
                          └─────────────────┘
```

## Run it

```bash
./run.sh            # fetches OPA for this platform, starts it, serves on :8000
./run.sh test       # 20 policy tests + 19 end-to-end tests
```

- Management UI — <http://localhost:8000/>
- Runtime console — <http://localhost:8000/runtime>

Requires Python 3.11+ and `pip install -r requirements.txt` (starlette, uvicorn,
pydantic). OPA is downloaded on first run for your OS and architecture; set
`OPA_PATH` to use one you already have.

## The two demo scenarios

**1 — access granted, then shielded, then redirected.** On the runtime console:

| Prompt | Outcome |
|---|---|
| *What MCP servers are available?* | Discovery only — five servers listed, no policy check |
| *Prepare a briefing on corporate credit exposure by industry and country.* | **ALLOW** — five records released |
| *Add the names and contact details of the five clients with the largest exposure increases.* | **DENY** — restricted PII, agent lacks clearance; a compliant alternative is offered |
| *Use the anonymised client exposure instead.* | **ALLOW** — anonymised records released |
| *Show me the US corporate credit exposure.* | **DENY** — data residency |
| *Show me the Luxembourg client exposure detail.* | **DENY** — banking secrecy |

**2 — the use case changes and the same prompt is denied.** Open the management UI
and the runtime console side by side:

1. Run *Prepare a briefing on corporate credit exposure…* → allowed.
2. In the management UI, open **Use-case registry** and set **Data regions** on
   *Corporate Credit Exposure Briefing* to `UK, Iran`.
3. The runtime console shows a metadata banner immediately; the policy impact
   matrix in the management UI turns red.
4. Run the **same prompt** again → denied at *Restricted jurisdiction*, zero records
   released, with the registry revision recorded against the decision.

Nothing about the agent or the policy changed. Only the use-case metadata did.

Other one-click levers: toggle **Cleared for PII** on the agent (denied → allowed),
or **AI access permitted** on a dataset (allowed → denied).

## The policy

`policy/access.rego`, package `poc.access`, evaluates seven dimensions and returns
one explainable decision:

| Dimension | Compares |
|---|---|
| AI access permission | data owner's AI-access flag on the dataset |
| Data residency | agent processing location vs MCP jurisdiction and data residency |
| PII processing | dataset PII classification vs agent clearance |
| Processing purpose | use-case purpose vs the server's permitted purposes |
| Restricted jurisdiction | every implicated region vs the policy registry's restricted list |
| Banking secrecy | client-identifying data in a secrecy jurisdiction |
| Privacy lawful basis | lawful basis and retention recorded on the use case |

`allow_access` requires all seven. It defaults to `false`, and the dimensions that
depend on policy-registry configuration require that configuration to be present,
so a missing policy registry denies rather than passing vacuously.

The policy declares its own `policy_version`. The client reports what comes back
rather than asserting a version of its own, so audit evidence cannot attest to a
version that is not loaded.

## Decisions taken in the merge

| Question | Resolution |
|---|---|
| Two OPA integrations (`opa eval` subprocess vs REST server) | **Server.** Fast enough per decision, holds the policy, supports decision logging. |
| Proven-Data's embedded Python evaluator | **Deleted.** It disagreed with its own Rego (approved-path controls, `.strip()` vs `== ""`) and fell back silently. A policy-as-code system cannot ship a hand-written shadow policy. The whitespace handling it got right is now in the Rego via `trim_space`. |
| Two policy families | **Merged into one package**, seven dimensions, one `decision` object. |
| Two metadata models | **Extended opa_demo's**, since its agent/service/dataset split already matches the conceptual design's three parties. Proven-Data's richer attributes folded in. |
| Where enforcement lives | **A gateway module**, not inside a tool implementation, so a new tool cannot forget to check. |
| Live or simulated agent | **Simulated only**, per decision during the build. It performs real discovery, makes real gateway calls and gets real OPA decisions; only the prose is scripted. `google-adk` is gone, which also dissolved the pydantic version conflict between the two repos. |
| Metadata store | **In memory.** Edits live for the process lifetime; a restart re-seeds. |
| Web framework | **Starlette**, the ASGI framework FastAPI is built on, used directly. Three dependencies instead of five; no HTTP client dependency, since OPA is reached over the standard library. |

### Problems in the source prototypes that are fixed here

- `policy_version` was a hardcoded client-side string — now it comes from the policy.
- Fail-closed responses carried an empty `raw_input` — the input now survives the
  failure, which is exactly when an auditor needs it.
- The Rego file was read from disk in three places with three path literals — now
  one constant, resolved from `__file__` rather than the working directory.
- Mock payloads lived inside the access-control metadata — now separated, so the
  catalogue describes data and the MCP server returns it.
- Agent output went through `dangerouslySetInnerHTML` with no escaping — the
  renderer here escapes first and formats second.
- SSE had no heartbeat and no reconnection — both added, with exponential backoff.
- Neither repo tested its policy. There are now 20 `opa test` cases and 19
  end-to-end tests against a real OPA.
- The OPA binary was committed as macOS arm64 only — `run.sh` fetches the right
  build for the host platform.

## Layout

```
app/
  config.py        paths from __file__, OPA endpoints, timeouts
  models.py        the common metadata model (pydantic)
  registries.py    five registries, seed data, change log
  gateway.py       the enforcement point
  opa_client.py    the only module that talks to OPA; fail-closed
  mcp_server.py    mocked data supplier
  agent.py         deterministic agent
  decision_log.py  decision records
  events.py        SSE fan-out
  main.py          routes
policy/
  access.rego      package poc.access
  access_test.rego 20 policy unit tests
static/            app.css, manage.*, runtime.*
templates/         manage.html, runtime.html
tests/test_e2e.py  19 end-to-end tests against a live stack
```

## API

| Endpoint | Purpose |
|---|---|
| `GET /api/metadata` | full registry snapshot plus change log |
| `PATCH /api/metadata/{kind}/{id}` | partial update; returns the before/after diff |
| `POST /api/metadata/reset` | re-seed |
| `POST /api/assess` | dry-run decision for a use case × service pairing |
| `POST /api/chat` | start an agent turn; the answer arrives over SSE |
| `GET /api/events` | the event stream |
| `GET /api/policy` | the Rego source |
| `GET /api/decisions` | the decision log |
| `GET /api/decisions/{correlation_id}` | one decision with its OPA input and output |

## Not in scope

Dashed boxes on the POC Full slide are not built: policy rule bundle management,
integration with real agent/MCP/policy-rule registries, and cloud monitoring. The
seams for them exist — the registries are behind one module, and the decision log
is already a separate store from the event stream.

All data is invented for demonstration.
