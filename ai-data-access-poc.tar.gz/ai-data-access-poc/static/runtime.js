/* ===========================================================================
   Runtime console — renders the request journey from the gateway's event
   stream. The five steps mirror the runtime sequence in the technical
   architecture, with the unified policy check expanded into its dimensions.
   =========================================================================== */

const STEPS = [
  { id: 1, title: "User request", note: "Prompt received by the agent" },
  { id: 2, title: "Discover MCP servers", note: "Agent reads the MCP / tool registry" },
  { id: 3, title: "Policy gateway check", note: "Decision engine evaluates all registries" },
  { id: 4, title: "Return data to agent", note: "Gateway calls the MCP server" },
  { id: 5, title: "Return answer to user", note: "Agent composes the response" },
];

const DIMENSIONS = {
  ai_access: "AI access permission",
  data_residency: "Data residency",
  pii_processing: "PII processing",
  processing_purpose: "Processing purpose",
  jurisdiction_sanction: "Restricted jurisdiction",
  banking_secrecy: "Banking secrecy",
  privacy_lawful_basis: "Privacy lawful basis",
};

const BARRIER_TEXT = {
  jurisdiction_sanction: "RESTRICTED JURISDICTION — BLOCKED",
  banking_secrecy: "BANKING SECRECY — SPECIALIST REVIEW REQUIRED",
  privacy_lawful_basis: "PRIVACY BASIS INCOMPLETE — BLOCKED",
  pii_processing: "RESTRICTED PII SHIELDED",
  data_residency: "RESIDENCY BOUNDARY ENFORCED",
  processing_purpose: "PURPOSE VALIDATION FAILED",
  ai_access: "AI ACCESS NOT PERMITTED BY DATA OWNER",
};

const CHIPS = [
  ["Discover", "What MCP servers are available?"],
  ["Aggregate (allow)", "Prepare a briefing on corporate credit exposure by industry and country."],
  ["Client PII (deny)", "Add the names and contact details of the five clients with the largest exposure increases."],
  ["Anonymised (allow)", "Use the anonymised client exposure instead."],
  ["US data (residency)", "Show me the US corporate credit exposure."],
  ["Luxembourg (secrecy)", "Show me the Luxembourg client exposure detail."],
];

const el = (id) => document.getElementById(id);

let state = freshState();
let lastDecision = { input: null, output: null };

function freshState() {
  return {
    correlationId: null,
    steps: { 1: "idle", 2: "idle", 3: "idle", 4: "idle", 5: "idle" },
    notes: {},
    dimensions: null,
    failed: [],
    policyVersion: null,
    approvalPath: null,
    revision: null,
    failClosed: false,
  };
}

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (c) => (
    { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]
  ));
}

function toast(message, kind = "") {
  const node = document.createElement("div");
  node.className = `toast ${kind}`;
  node.textContent = message;
  el("toasts").appendChild(node);
  setTimeout(() => node.remove(), 4500);
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.detail ? JSON.stringify(body.detail) : response.statusText);
  return body;
}

/* --- markdown ------------------------------------------------------------
   Everything is HTML-escaped before any formatting is applied, so agent output
   is rendered as text and never as markup. */

function inline(text) {
  return esc(text)
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/(^|[^*])\*([^*]+?)\*/g, "$1<em>$2</em>")
    .replace(/`([^`]+?)`/g, "<code>$1</code>");
}

function renderMarkdown(source) {
  const lines = String(source).split("\n");
  const out = [];
  let list = null;
  let table = null;

  const closeList = () => { if (list) { out.push(`<ul>${list.join("")}</ul>`); list = null; } };
  const closeTable = () => {
    if (table) {
      const [head, ...rows] = table;
      out.push(
        `<table><thead><tr>${head.map((c) => `<th>${inline(c)}</th>`).join("")}</tr></thead>` +
        `<tbody>${rows.map((r) => `<tr>${r.map((c) => `<td>${inline(c)}</td>`).join("")}</tr>`).join("")}</tbody></table>`
      );
      table = null;
    }
  };

  for (const raw of lines) {
    const line = raw.trimEnd();

    if (/^\|(.+)\|$/.test(line)) {
      const cells = line.slice(1, -1).split("|").map((c) => c.trim());
      if (cells.every((c) => /^-{2,}$/.test(c))) continue; // divider row
      closeList();
      (table ||= []).push(cells);
      continue;
    }
    closeTable();

    if (/^\s*[-*]\s+/.test(line)) {
      (list ||= []).push(`<li>${inline(line.replace(/^\s*[-*]\s+/, ""))}</li>`);
      continue;
    }
    closeList();

    if (/^###\s+/.test(line)) { out.push(`<h3>${inline(line.replace(/^###\s+/, ""))}</h3>`); continue; }
    if (!line.trim()) continue;
    out.push(`<p>${inline(line)}</p>`);
  }

  closeList();
  closeTable();
  return out.join("");
}

/* --- conversation -------------------------------------------------------- */

function addBubble(html, className) {
  const node = document.createElement("div");
  node.className = `bubble ${className}`;
  node.innerHTML = html;
  el("conversation").appendChild(node);
  node.scrollIntoView({ behavior: "smooth", block: "end" });
  return node;
}

function showTyping(model) {
  removeTyping();
  const node = document.createElement("div");
  node.className = "bubble agent";
  node.id = "typing-bubble";
  node.innerHTML = `<div class="typing"><span></span><span></span><span></span> ${esc(model || "working")}…</div>`;
  el("conversation").appendChild(node);
  node.scrollIntoView({ behavior: "smooth", block: "end" });
}

function removeTyping() {
  el("typing-bubble")?.remove();
}

/* --- journey ------------------------------------------------------------- */

function renderJourney() {
  el("journey").innerHTML = STEPS.map((step) => {
    const status = state.steps[step.id];
    let inner = `<div class="step-title">${esc(step.title)}</div>
      <div class="step-note">${esc(state.notes[step.id] || step.note)}</div>`;

    if (step.id === 3 && state.dimensions) {
      const rows = Object.entries(DIMENSIONS)
        .filter(([key]) => state.dimensions[key])
        .map(([key, label]) => {
          const verdict = state.dimensions[key];
          const passed = verdict.status === "PASSED";
          return `<div class="substep ${passed ? "passed" : "failed"}">
            <span class="mark">${passed ? "✓" : "✕"}</span>
            <span><span class="name">${esc(label)}</span>
            <span class="reason">${esc(verdict.reason)}</span></span>
          </div>`;
        })
        .join("");
      inner += `<div class="substeps">${rows}</div>`;
    }

    if (step.id === 4 && status === "failed") {
      const primary = state.failed[0];
      inner += `<div class="barrier">${esc(BARRIER_TEXT[primary] || "ACCESS DENIED")}</div>`;
    }

    return `<div class="step ${status}" data-n="${step.id}">${inner}</div>`;
  }).join("");
}

/* --- audit --------------------------------------------------------------- */

function renderAudit() {
  const items = [
    ["Correlation ID", state.correlationId || "—"],
    ["Policy version", state.policyVersion || "—"],
    ["Registry revision", state.revision ?? "—"],
    ["Approval path", state.approvalPath || "—"],
  ];
  el("audit-kv").innerHTML = items
    .map(([k, v]) => `<div class="kv-item"><div class="k">${esc(k)}</div><div class="v">${esc(v)}</div></div>`)
    .join("");
}

async function refreshLog() {
  try {
    const { summary, records } = await api("/api/decisions?limit=25");
    el("log-badge").textContent =
      `${summary.total} decision${summary.total === 1 ? "" : "s"} · ${summary.allowed} allowed · ${summary.denied} denied`;

    if (!records.length) {
      el("decision-log").innerHTML =
        '<p class="small muted" style="margin:0">No decisions recorded yet.</p>';
      return;
    }

    el("decision-log").innerHTML = records
      .map((record) => {
        const detail = record.allowed
          ? `${record.record_count} records released from <code>${esc(record.dataset_id)}</code> · ${esc(record.approval_path)}`
          : `${record.failed_dimensions.map((d) => esc(DIMENSIONS[d] || d)).join(", ")} · ${esc(record.approval_path)}`;
        return `<div class="log-entry">
          <div class="head">
            <span class="badge ${record.allowed ? "allow" : "deny"}">${record.allowed ? "allow" : "deny"}</span>
            <span class="svc">${esc(record.service_id)}</span>
            <span class="cid">${esc(record.correlation_id)}</span>
          </div>
          <div class="detail">${detail}</div>
        </div>`;
      })
      .join("");
  } catch {
    /* leave the previous view in place */
  }
}

/* --- event handling ------------------------------------------------------ */

function handle(event) {
  const payload = event.payload || {};

  switch (event.event_type) {
    case "connected":
      setStream(true);
      break;

    case "metadata_changed": {
      state.revision = payload.revision;
      el("revision").textContent = payload.revision;
      el("meta-banner-text").textContent =
        `${payload.description}. The next request will be decided against this.`;
      el("meta-banner").hidden = false;
      renderAudit();
      break;
    }

    case "demo_reset":
      resetView();
      break;

    case "agent_start":
      state = freshState();
      state.correlationId = event.correlation_id;
      state.steps[1] = "done";
      state.steps[2] = "active";
      state.notes[1] = `Use case: ${payload.use_case_id}`;
      addBubble(`<p>${esc(payload.prompt)}</p>`, "user");
      el("agent-badge").textContent = "running";
      el("journey-badge").textContent = "in flight";
      el("journey-badge").className = "badge info";
      renderJourney();
      renderAudit();
      break;

    case "agent_thinking":
      showTyping(payload.model);
      break;

    case "discovery_started":
      state.steps[2] = "active";
      state.notes[2] = `Purpose declared: ${payload.purpose}`;
      renderJourney();
      break;

    case "discovery_candidates_found":
      state.steps[2] = "done";
      state.notes[2] = `${payload.count} MCP servers catalogued`;
      renderJourney();
      break;

    case "connection_request":
      state.steps[3] = "active";
      state.notes[3] = `Requesting ${payload.service_id}`;
      renderJourney();
      break;

    case "checkpoint_start":
      state.steps[3] = "active";
      state.revision = payload.registry_revision;
      state.notes[3] = `Evaluating ${payload.dataset.id} for ${payload.agent.id}`;
      el("revision").textContent = payload.registry_revision;
      renderJourney();
      renderAudit();
      break;

    case "checkpoint_result": {
      const allowed = payload.status === "ALLOWED";
      state.dimensions = payload.dimensions;
      state.policyVersion = payload.policy_version;
      state.approvalPath = payload.approval_path;
      state.revision = payload.registry_revision;
      state.failClosed = payload.fail_closed;
      state.failed = Object.entries(payload.dimensions)
        .filter(([, v]) => v.status === "FAILED")
        .map(([k]) => k);
      state.steps[3] = allowed ? "done" : "failed";
      state.notes[3] = payload.reason;
      lastDecision = { input: payload.opa_input, output: payload.opa_output };
      if (payload.fail_closed) toast("Policy engine unavailable — failed closed", "err");
      renderJourney();
      renderAudit();
      break;
    }

    case "data_released":
      state.steps[4] = "done";
      state.steps[5] = "active";
      state.notes[4] = `${payload.record_count} records released from ${payload.dataset_id}`;
      renderJourney();
      break;

    case "access_denied":
      state.steps[4] = "failed";
      state.steps[5] = "active";
      state.notes[4] = "Blocked at the gateway — no data left the MCP server";
      renderJourney();
      break;

    case "checkpoint_failed":
      state.steps[3] = "failed";
      state.notes[3] = payload.reason;
      renderJourney();
      break;

    case "agent_done": {
      removeTyping();
      state.steps[5] = "done";
      const denied = state.steps[4] === "failed";
      const touched = state.steps[3] !== "idle";
      addBubble(
        renderMarkdown(payload.response),
        `agent ${touched ? (denied ? "denied" : "allowed") : ""}`
      );
      el("agent-badge").textContent = "idle";
      el("journey-badge").textContent = denied ? "denied" : touched ? "allowed" : "complete";
      el("journey-badge").className = `badge ${denied ? "deny" : touched ? "allow" : "info"}`;
      el("send").disabled = false;
      renderJourney();
      refreshLog();
      break;
    }

    case "agent_error":
      removeTyping();
      state.steps[5] = "failed";
      addBubble(`<p><strong>Agent error.</strong> ${esc(payload.message)}</p>`, "agent denied");
      el("agent-badge").textContent = "error";
      el("send").disabled = false;
      renderJourney();
      break;
  }
}

/* --- stream with reconnect ------------------------------------------------ */

let stream = null;
let retryDelay = 1000;

function setStream(up) {
  el("stream-dot").className = `dot ${up ? "live" : "down"}`;
  el("stream-text").textContent = up ? "stream live" : "reconnecting";
}

function connect() {
  stream = new EventSource("/api/events");

  stream.onopen = () => {
    retryDelay = 1000;
    setStream(true);
  };

  stream.onmessage = (message) => {
    try {
      handle(JSON.parse(message.data));
    } catch (error) {
      console.error("bad event", error);
    }
  };

  stream.onerror = () => {
    setStream(false);
    stream.close();
    setTimeout(connect, retryDelay);
    retryDelay = Math.min(retryDelay * 2, 15000);
  };
}

/* --- actions ------------------------------------------------------------- */

function resetView() {
  state = freshState();
  lastDecision = { input: null, output: null };
  el("conversation").innerHTML = "";
  el("meta-banner").hidden = true;
  el("agent-badge").textContent = "no agent run yet";
  el("journey-badge").textContent = "idle";
  el("journey-badge").className = "badge";
  addBubble(
    `<h3>Policy-gated data agent</h3><p>Conversation reset. The registries are unchanged — reset those from the Metadata &amp; Policy page.</p>`,
    "agent"
  );
  renderJourney();
  renderAudit();
  refreshLog();
}

el("composer").onsubmit = async (event) => {
  event.preventDefault();
  const prompt = el("prompt").value.trim();
  if (!prompt) return;
  el("prompt").value = "";
  el("send").disabled = true;
  try {
    await api("/api/chat", {
      method: "POST",
      body: JSON.stringify({ prompt, use_case_id: el("use-case").value }),
    });
  } catch (error) {
    toast(`Could not reach the backend: ${error.message}`, "err");
    el("send").disabled = false;
  }
};

el("btn-reset").onclick = async () => {
  await api("/api/reset", { method: "POST" });
};

el("btn-policy").onclick = async () => {
  el("policy-modal").hidden = false;
  el("opa-input").textContent = lastDecision.input
    ? JSON.stringify(lastDecision.input, null, 2)
    : "No decision yet in this session.";
  el("opa-output").textContent = lastDecision.output
    ? JSON.stringify(lastDecision.output, null, 2)
    : "No decision yet in this session.";
  try {
    const { policy } = await api("/api/policy");
    el("policy-source").textContent = policy;
  } catch (error) {
    el("policy-source").textContent = `Could not load policy: ${error.message}`;
  }
};

el("btn-close-policy").onclick = () => (el("policy-modal").hidden = true);
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") el("policy-modal").hidden = true;
});

/* --- boot ---------------------------------------------------------------- */

el("chips").innerHTML = CHIPS.map(
  ([label, prompt], i) => `<button type="button" data-i="${i}">${esc(label)}</button>`
).join("");

el("chips").querySelectorAll("button").forEach((button) => {
  button.onclick = () => {
    el("prompt").value = CHIPS[button.dataset.i][1];
    el("prompt").focus();
  };
});

async function boot() {
  try {
    const metadata = await api("/api/metadata");
    state.revision = metadata.revision;
    el("revision").textContent = metadata.revision;
    el("use-case").innerHTML = metadata.use_cases
      .map((u) => `<option value="${esc(u.id)}">${esc(u.name)}</option>`)
      .join("");
  } catch {
    toast("Could not load the registries", "err");
  }
  renderJourney();
  renderAudit();
  refreshLog();
  connect();
}

boot();
