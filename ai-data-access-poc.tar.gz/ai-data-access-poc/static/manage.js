/* ===========================================================================
   Management UI — the five registries plus the policy rule set.
   Every edit PATCHes the registry the gateway reads, then re-evaluates the
   policy impact matrix so the consequence of the change is immediately visible.
   =========================================================================== */

const KINDS = [
  { key: "agents", label: "Agent registry" },
  { key: "use_cases", label: "Use-case registry" },
  { key: "datasets", label: "Data catalogue" },
  { key: "services", label: "MCP / tool registry" },
  { key: "policy", label: "Policy rules" },
];

/* Field descriptors. Only fields the policy or the UI actually uses appear. */
const SCHEMA = {
  agents: [
    { name: "name", type: "text", label: "Name", wide: true },
    { name: "owner", type: "text", label: "Owner", wide: true },
    { name: "processing_location", type: "text", label: "Processing location" },
    { name: "can_process_pii", type: "bool", label: "Cleared for PII" },
    { name: "permitted_actions", type: "list", label: "Permitted actions", wide: true },
  ],
  use_cases: [
    { name: "name", type: "text", label: "Name", wide: true },
    { name: "owner", type: "text", label: "Owner", wide: true },
    { name: "agent_id", type: "ref", ref: "agents", label: "Agent" },
    { name: "purpose", type: "text", label: "Processing purpose" },
    { name: "user_role", type: "text", label: "User role" },
    { name: "data_regions", type: "list", label: "Data regions" },
    { name: "lawful_basis", type: "text", label: "Lawful basis", wide: true },
    { name: "retention_period", type: "text", label: "Retention period", wide: true },
  ],
  datasets: [
    { name: "name", type: "text", label: "Name", wide: true },
    { name: "owner", type: "text", label: "Owner", wide: true },
    { name: "data_jurisdiction", type: "text", label: "Data residency" },
    {
      name: "pii_classification",
      type: "enum",
      label: "PII classification",
      options: ["none", "restricted_pii"],
    },
    {
      name: "identity_type",
      type: "enum",
      label: "Identity type",
      options: ["true_identity", "internal_ids_only", "not_applicable"],
      wide: true,
    },
    { name: "contains_client_data", type: "bool", label: "Contains client data" },
    { name: "employee_only_access", type: "bool", label: "Employee-only access" },
    { name: "ai_access_permitted", type: "bool", label: "AI access permitted" },
  ],
  services: [
    { name: "name", type: "text", label: "Name", wide: true },
    { name: "owner", type: "text", label: "Owner", wide: true },
    { name: "description", type: "textarea", label: "Description (visible to agents)", wide: true },
    { name: "jurisdiction", type: "text", label: "Jurisdiction" },
    { name: "dataset_id", type: "ref", ref: "datasets", label: "Serves dataset" },
    {
      name: "permitted_processing_purposes",
      type: "list",
      label: "Permitted purposes",
      wide: true,
    },
  ],
  policy: [
    { name: "owner", type: "text", label: "Owner", wide: true },
    { name: "restricted_jurisdictions", type: "list", label: "Restricted jurisdictions", wide: true },
    {
      name: "banking_secrecy_jurisdictions",
      type: "list",
      label: "Banking secrecy jurisdictions",
      wide: true,
    },
  ],
};

let data = null;
let activeTab = "agents";

const el = (id) => document.getElementById(id);

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (c) => (
    { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]
  ));
}

function toast(message, kind = "") {
  const node = document.createElement("div");
  node.className = `toast ${kind}`;
  node.textContent = message;
  el("toasts").appendChild(node);
  setTimeout(() => node.remove(), 4200);
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.detail ? JSON.stringify(body.detail) : response.statusText);
  return body;
}

/* --- rendering ----------------------------------------------------------- */

function recordsFor(kind) {
  return kind === "policy" ? [data.policy] : data[kind];
}

function renderTabs() {
  el("tabs").innerHTML = KINDS.map((k) => {
    const count = kind_count(k.key);
    return `<button data-tab="${k.key}" class="${k.key === activeTab ? "active" : ""}">
      ${esc(k.label)}<span class="count">${count}</span></button>`;
  }).join("");
  el("tabs").querySelectorAll("button").forEach((button) => {
    button.onclick = () => {
      activeTab = button.dataset.tab;
      renderTabs();
      renderRecords();
    };
  });
}

function kind_count(kind) {
  return kind === "policy" ? 1 : (data[kind] || []).length;
}

function fieldControl(kind, record, field) {
  const id = `f-${kind}-${record.id}-${field.name}`;
  const value = record[field.name];
  const common = `id="${id}" data-kind="${kind}" data-record="${esc(record.id)}" data-field="${field.name}"`;

  if (field.type === "bool") {
    return `<label class="toggle" for="${id}">
      <input type="checkbox" ${common} ${value ? "checked" : ""} />
      <span class="track"></span>
      <span class="toggle-label">${esc(field.label)}</span>
    </label>`;
  }

  let control;
  if (field.type === "enum") {
    control = `<select ${common}>${field.options
      .map((o) => `<option value="${esc(o)}" ${o === value ? "selected" : ""}>${esc(o)}</option>`)
      .join("")}</select>`;
  } else if (field.type === "ref") {
    const options = (data[field.ref] || [])
      .map(
        (r) =>
          `<option value="${esc(r.id)}" ${r.id === value ? "selected" : ""}>${esc(r.name)} (${esc(r.id)})</option>`
      )
      .join("");
    control = `<select ${common}>${options}</select>`;
  } else if (field.type === "textarea") {
    control = `<textarea ${common} rows="2">${esc(value ?? "")}</textarea>`;
  } else if (field.type === "list") {
    control = `<input type="text" ${common} value="${esc((value || []).join(", "))}"
      placeholder="comma separated" />`;
  } else {
    control = `<input type="text" ${common} value="${esc(value ?? "")}" />`;
  }

  return `<label class="field" for="${id}"><span>${esc(field.label)}</span>${control}</label>`;
}

function renderRecords() {
  const fields = SCHEMA[activeTab];
  const records = recordsFor(activeTab);
  const touched = new Set(data.changes.filter((c) => c.kind === activeTab).map((c) => c.record_id));

  el("records").innerHTML = records
    .map((record) => {
      const wide = fields.filter((f) => f.wide || f.type === "textarea");
      const narrow = fields.filter((f) => !f.wide && f.type !== "textarea");
      return `<div class="record ${touched.has(record.id) ? "changed" : ""}">
        <div class="record-head">
          <h3>${esc(record.name || "Policy rule set")}</h3>
          ${touched.has(record.id) ? '<span class="badge warn">edited</span>' : ""}
        </div>
        <div class="record-id">${esc(record.id)}</div>
        ${wide.map((f) => fieldControl(activeTab, record, f)).join("")}
        <div class="field-row">
          ${narrow.map((f) => fieldControl(activeTab, record, f)).join("")}
        </div>
      </div>`;
    })
    .join("");

  el("records").querySelectorAll("[data-field]").forEach((input) => {
    const handler = input.type === "checkbox" || input.tagName === "SELECT" ? "change" : "change";
    input.addEventListener(handler, onFieldChange);
  });
}

async function onFieldChange(event) {
  const input = event.target;
  const { kind, record, field } = input.dataset;
  const descriptor = SCHEMA[kind].find((f) => f.name === field);

  let value;
  if (descriptor.type === "bool") value = input.checked;
  else if (descriptor.type === "list") {
    value = input.value.split(",").map((s) => s.trim()).filter(Boolean);
  } else value = input.value;

  try {
    const outcome = await api(`/api/metadata/${kind}/${encodeURIComponent(record)}`, {
      method: "PATCH",
      body: JSON.stringify({ changes: { [field]: value } }),
    });
    data.revision = outcome.revision;
    data.changes.unshift(outcome.change);
    el("revision").textContent = outcome.revision;
    toast(describe(outcome.change), "ok");
    await refresh({ keepTab: true });
  } catch (error) {
    toast(`Rejected: ${error.message}`, "err");
    await refresh({ keepTab: true });
  }
}

function fmt(value) {
  if (typeof value === "boolean") return value ? "yes" : "no";
  if (Array.isArray(value)) return value.length ? value.join(", ") : "(none)";
  if (value === "" || value === null || value === undefined) return "(empty)";
  return String(value);
}

function describe(change) {
  const parts = Object.entries(change.diff).map(
    ([field, v]) => `${field}: ${fmt(v.from)} → ${fmt(v.to)}`
  );
  return parts.length ? `${change.label} — ${parts.join("; ")}` : `${change.label} saved`;
}

function renderChanges() {
  const container = el("changes");
  if (!data.changes.length) {
    container.innerHTML = '<p class="small muted" style="margin:0">No metadata changes yet.</p>';
    return;
  }
  container.innerHTML = data.changes
    .map((change) => {
      const diff = Object.entries(change.diff)
        .map(([field, v]) => `<div class="diff">${esc(field)}: ${esc(fmt(v.from))} → <b>${esc(fmt(v.to))}</b></div>`)
        .join("");
      return `<div class="change-item">
        <div class="when"><span>rev ${change.revision}</span><span>${esc(change.timestamp.replace("T", " ").replace("+00:00", "Z"))}</span></div>
        <div class="what">${esc(change.label)}</div>
        ${diff}
      </div>`;
    })
    .join("");
}

/* --- policy impact matrix ------------------------------------------------ */

const DIMENSION_LABELS = {
  ai_access: "AI access",
  data_residency: "Residency",
  pii_processing: "PII",
  processing_purpose: "Purpose",
  jurisdiction_sanction: "Restricted region",
  banking_secrecy: "Banking secrecy",
  privacy_lawful_basis: "Privacy basis",
};

async function renderMatrix() {
  const useCases = data.use_cases;
  const services = data.services;
  const table = el("matrix");

  table.innerHTML =
    `<thead><tr><th class="row-head">Use case \\ MCP server</th>` +
    services.map((s) => `<th>${esc(s.name)}</th>`).join("") +
    `</tr></thead><tbody>` +
    useCases
      .map(
        (u) =>
          `<tr><th class="row-head">${esc(u.name)}</th>` +
          services.map((s) => `<td id="cell-${esc(u.id)}-${esc(s.id)}"><div class="cell"><span class="verdict muted">…</span></div></td>`).join("") +
          `</tr>`
      )
      .join("") +
    `</tbody>`;

  const jobs = [];
  for (const u of useCases) {
    for (const s of services) {
      jobs.push(
        api("/api/assess", {
          method: "POST",
          body: JSON.stringify({ use_case_id: u.id, service_id: s.id }),
        })
          .then((result) => ({ u, s, result }))
          .catch(() => ({ u, s, result: null }))
      );
    }
  }

  for (const { u, s, result } of await Promise.all(jobs)) {
    const cell = el(`cell-${u.id}-${s.id}`);
    if (!cell) continue;
    if (!result) {
      cell.innerHTML = '<div class="cell"><span class="verdict muted">error</span></div>';
      continue;
    }
    const failed = Object.entries(result.dimensions)
      .filter(([, v]) => v.status === "FAILED")
      .map(([k]) => DIMENSION_LABELS[k] || k);
    const why = result.allowed ? result.approval_path : failed.join(", ");
    const tip = result.allowed
      ? result.overall.reason
      : Object.entries(result.dimensions)
          .filter(([, v]) => v.status === "FAILED")
          .map(([k, v]) => `${DIMENSION_LABELS[k] || k}: ${v.reason}`)
          .join("\n");
    cell.innerHTML = `<div class="cell ${result.allowed ? "allow" : "deny"}" title="${esc(tip)}">
      <span class="verdict">${result.allowed ? "ALLOW" : "DENY"}</span>
      <span class="why">${esc(why)}</span>
    </div>`;
  }
}

/* --- lifecycle ----------------------------------------------------------- */

async function refresh({ keepTab = false } = {}) {
  data = await api("/api/metadata");
  el("revision").textContent = data.revision;
  if (!keepTab) activeTab = activeTab || "agents";
  renderTabs();
  renderRecords();
  renderChanges();
  await renderMatrix();
}

async function pollHealth() {
  try {
    const health = await api("/health");
    el("opa-dot").className = `dot ${health.opa_reachable ? "live" : "down"}`;
    el("opa-text").textContent = health.opa_reachable ? "OPA connected" : "OPA unreachable";
  } catch {
    el("opa-dot").className = "dot down";
    el("opa-text").textContent = "API unreachable";
  }
}

el("btn-policy").onclick = async () => {
  el("policy-modal").hidden = false;
  try {
    const { policy } = await api("/api/policy");
    el("policy-source").textContent = policy;
  } catch (error) {
    el("policy-source").textContent = `Could not load policy: ${error.message}`;
  }
};

el("btn-close-policy").onclick = () => (el("policy-modal").hidden = true);
el("btn-refresh-matrix").onclick = () => renderMatrix();

el("btn-reset").onclick = async () => {
  await api("/api/metadata/reset", { method: "POST" });
  toast("Registries reset to seeded values", "ok");
  await refresh({ keepTab: true });
};

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") el("policy-modal").hidden = true;
});

/* Another tab (or the runtime console) may change metadata too. */
const stream = new EventSource("/api/events");
stream.onmessage = (message) => {
  const event = JSON.parse(message.data);
  if (event.event_type === "metadata_changed" && event.payload.revision !== data?.revision) {
    refresh({ keepTab: true });
  }
};

refresh();
pollHealth();
setInterval(pollHealth, 10000);
