"""End-to-end tests.

These boot the real application against a real OPA and drive it over HTTP,
including the event stream. Nothing is mocked, so a passing run means the
gateway, the registries, the policy and the event plumbing agree with each
other — which is the property the two source prototypes could not demonstrate.

    python3 -m unittest discover -s tests -v

Requires an OPA server already listening (./run.sh test does this for you).
"""

from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import threading
import time
import unittest
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OPA_PORT = os.environ.get("OPA_PORT", "8181")


def free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


class ApiClient:
    def __init__(self, base: str) -> None:
        self.base = base

    def call(self, path: str, method: str = "GET", body: dict | None = None):
        data = json.dumps(body).encode() if body is not None else None
        request = urllib.request.Request(self.base + path, data=data, method=method)
        if data:
            request.add_header("Content-Type", "application/json")
        with urllib.request.urlopen(request, timeout=15) as response:
            return json.loads(response.read())

    def verdict(self, service_id: str, use_case_id: str = "uc_credit_briefing"):
        result = self.call(
            "/api/assess", "POST", {"use_case_id": use_case_id, "service_id": service_id}
        )
        failed = [k for k, v in result["dimensions"].items() if v["status"] == "FAILED"]
        return result["allowed"], failed, result

    def patch(self, kind: str, record_id: str, changes: dict):
        return self.call(f"/api/metadata/{kind}/{record_id}", "PATCH", {"changes": changes})


class PocTestCase(unittest.TestCase):
    server: subprocess.Popen
    api: ApiClient

    @classmethod
    def setUpClass(cls) -> None:
        port = free_port()
        cls.server = subprocess.Popen(
            [
                sys.executable, "-m", "uvicorn", "app.main:app",
                "--host", "127.0.0.1", "--port", str(port), "--log-level", "warning",
            ],
            cwd=ROOT,
            env={**os.environ, "OPA_HOST": f"http://localhost:{OPA_PORT}"},
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        cls.api = ApiClient(f"http://127.0.0.1:{port}")

        for _ in range(60):
            try:
                health = cls.api.call("/health")
                if health.get("opa_reachable"):
                    return
            except (urllib.error.URLError, OSError):
                pass
            time.sleep(0.4)
        cls.tearDownClass()
        raise RuntimeError("application did not become ready with OPA reachable")

    @classmethod
    def tearDownClass(cls) -> None:
        cls.server.terminate()
        try:
            cls.server.wait(timeout=10)
        except subprocess.TimeoutExpired:
            cls.server.kill()

    def setUp(self) -> None:
        self.api.call("/api/metadata/reset", "POST")
        self.api.call("/api/reset", "POST")


class TestSeededDecisions(PocTestCase):
    def test_aggregate_is_allowed(self):
        allowed, failed, result = self.api.verdict("corporate_aggregate_mcp")
        self.assertTrue(allowed)
        self.assertEqual(failed, [])
        self.assertEqual(result["approval_path"], "Existing entitlement / proportionate approval")

    def test_restricted_pii_is_denied(self):
        allowed, failed, _ = self.api.verdict("corporate_pii_mcp")
        self.assertFalse(allowed)
        self.assertEqual(failed, ["pii_processing"])

    def test_anonymised_alternative_is_allowed(self):
        allowed, failed, _ = self.api.verdict("corporate_anonymised_mcp")
        self.assertTrue(allowed)
        self.assertEqual(failed, [])

    def test_cross_border_is_denied_on_residency(self):
        allowed, failed, _ = self.api.verdict("us_corporate_mcp")
        self.assertFalse(allowed)
        self.assertIn("data_residency", failed)

    def test_luxembourg_is_denied_on_banking_secrecy(self):
        allowed, failed, _ = self.api.verdict("lux_client_mcp")
        self.assertFalse(allowed)
        self.assertIn("banking_secrecy", failed)

    def test_policy_version_comes_from_the_policy(self):
        _, _, result = self.api.verdict("corporate_aggregate_mcp")
        self.assertEqual(result["policy_version"], "poc.access/v2.1.0")
        self.assertFalse(result["fail_closed"])


class TestMetadataChangesTheDecision(PocTestCase):
    """The POC's second demo scenario, and its inverses."""

    def test_use_case_targeting_restricted_region_flips_to_deny(self):
        self.assertTrue(self.api.verdict("corporate_aggregate_mcp")[0])

        self.api.patch("use_cases", "uc_credit_briefing", {"data_regions": ["UK", "Iran"]})

        allowed, failed, result = self.api.verdict("corporate_aggregate_mcp")
        self.assertFalse(allowed)
        self.assertEqual(failed, ["jurisdiction_sanction"])
        self.assertEqual(result["approval_path"], "Blocked — restricted jurisdiction")

        self.api.patch("use_cases", "uc_credit_briefing", {"data_regions": ["UK"]})
        self.assertTrue(self.api.verdict("corporate_aggregate_mcp")[0])

    def test_pii_clearance_uplift_flips_to_allow(self):
        self.assertFalse(self.api.verdict("corporate_pii_mcp")[0])
        self.api.patch("agents", "briefing_agent_01", {"can_process_pii": True})
        self.assertTrue(self.api.verdict("corporate_pii_mcp")[0])

    def test_data_owner_can_withdraw_ai_access(self):
        self.assertTrue(self.api.verdict("corporate_aggregate_mcp")[0])
        self.api.patch("datasets", "ds_aggregate_exposure", {"ai_access_permitted": False})
        allowed, failed, _ = self.api.verdict("corporate_aggregate_mcp")
        self.assertFalse(allowed)
        self.assertEqual(failed, ["ai_access"])

    def test_policy_owner_can_add_a_restricted_jurisdiction(self):
        self.assertFalse(self.api.verdict("us_corporate_mcp")[0])
        self.api.patch("policy", "default", {"restricted_jurisdictions": ["Iran", "US"]})
        _, failed, _ = self.api.verdict("us_corporate_mcp")
        self.assertIn("jurisdiction_sanction", failed)

    def test_change_is_recorded_with_a_before_and_after(self):
        outcome = self.api.patch("use_cases", "uc_credit_briefing", {"data_regions": ["UK", "Iran"]})
        diff = outcome["change"]["diff"]["data_regions"]
        self.assertEqual(diff["from"], ["UK"])
        self.assertEqual(diff["to"], ["UK", "Iran"])

    def test_invalid_value_is_rejected_and_nothing_changes(self):
        with self.assertRaises(urllib.error.HTTPError) as caught:
            self.api.patch("datasets", "ds_aggregate_exposure", {"pii_classification": "nonsense"})
        self.assertEqual(caught.exception.code, 422)
        self.assertTrue(self.api.verdict("corporate_aggregate_mcp")[0])

    def test_unknown_record_is_a_404(self):
        with self.assertRaises(urllib.error.HTTPError) as caught:
            self.api.patch("agents", "does_not_exist", {"name": "x"})
        self.assertEqual(caught.exception.code, 404)


class TestAgentRuntime(PocTestCase):
    def _run_turn(self, prompt: str, timeout: float = 20.0) -> list[dict]:
        """Send a prompt and collect its events up to agent_done."""
        events: list[dict] = []
        done = threading.Event()

        def listen():
            request = urllib.request.Request(self.api.base + "/api/events")
            with urllib.request.urlopen(request, timeout=timeout) as response:
                for raw in response:
                    line = raw.decode().strip()
                    if not line.startswith("data: "):
                        continue
                    event = json.loads(line[6:])
                    events.append(event)
                    if event["event_type"] in ("agent_done", "agent_error"):
                        done.set()
                        return

        thread = threading.Thread(target=listen, daemon=True)
        thread.start()
        time.sleep(0.6)
        self.api.call("/api/chat", "POST", {"prompt": prompt})
        done.wait(timeout)
        return events

    def _event(self, events: list[dict], event_type: str) -> dict | None:
        return next((e for e in events if e["event_type"] == event_type), None)

    def test_allowed_turn_releases_data_and_logs_it(self):
        events = self._run_turn("Prepare a briefing on corporate credit exposure by industry.")

        checkpoint = self._event(events, "checkpoint_result")
        self.assertIsNotNone(checkpoint)
        self.assertEqual(checkpoint["payload"]["status"], "ALLOWED")

        released = self._event(events, "data_released")
        self.assertIsNotNone(released)
        self.assertEqual(released["payload"]["record_count"], 5)

        answer = self._event(events, "agent_done")["payload"]["response"]
        self.assertIn("Financial Services", answer)

        log = self.api.call("/api/decisions")
        self.assertEqual(log["summary"]["allowed"], 1)
        self.assertEqual(log["records"][0]["record_count"], 5)

    def test_denied_turn_releases_nothing(self):
        events = self._run_turn("Add the names and contact details of the largest clients.")

        self.assertEqual(self._event(events, "checkpoint_result")["payload"]["status"], "DENIED")
        self.assertIsNone(self._event(events, "data_released"))

        denied = self._event(events, "access_denied")
        self.assertEqual(denied["payload"]["failed_dimensions"], ["pii_processing"])

        answer = self._event(events, "agent_done")["payload"]["response"]
        self.assertIn("blocked", answer.lower())
        # The real client names must not appear anywhere in the response.
        self.assertNotIn("Northgate", answer)

        log = self.api.call("/api/decisions")
        self.assertEqual(log["summary"]["denied"], 1)
        self.assertEqual(log["records"][0]["record_count"], 0)

    def test_same_prompt_changes_outcome_after_a_metadata_edit(self):
        prompt = "Prepare a briefing on corporate credit exposure by industry."

        first = self._run_turn(prompt)
        self.assertEqual(self._event(first, "checkpoint_result")["payload"]["status"], "ALLOWED")

        self.api.patch("use_cases", "uc_credit_briefing", {"data_regions": ["UK", "Iran"]})

        second = self._run_turn(prompt)
        result = self._event(second, "checkpoint_result")["payload"]
        self.assertEqual(result["status"], "DENIED")
        self.assertEqual(result["dimensions"]["jurisdiction_sanction"]["status"], "FAILED")
        self.assertIsNone(self._event(second, "data_released"))

    def test_discovery_turn_lists_servers_without_a_policy_check(self):
        events = self._run_turn("What MCP servers are available?")
        self.assertEqual(self._event(events, "discovery_candidates_found")["payload"]["count"], 5)
        self.assertIsNone(self._event(events, "checkpoint_result"))

    def test_every_decision_is_logged_with_its_opa_input(self):
        events = self._run_turn("Show me the US corporate credit exposure.")
        correlation_id = self._event(events, "agent_start")["correlation_id"]
        records = self.api.call(f"/api/decisions/{correlation_id}")["records"]
        self.assertEqual(len(records), 1)
        self.assertIn("agent", records[0]["opa_input"])
        self.assertIn("dataset", records[0]["opa_input"])
        self.assertIn("policy", records[0]["opa_input"])


class TestFailClosed(PocTestCase):
    def test_unreachable_opa_denies_and_still_reports_the_input(self):
        """Point the app at a port with nothing on it."""
        port = free_port()
        app_port = free_port()
        server = subprocess.Popen(
            [
                sys.executable, "-m", "uvicorn", "app.main:app",
                "--host", "127.0.0.1", "--port", str(app_port), "--log-level", "error",
            ],
            cwd=ROOT,
            env={**os.environ, "OPA_HOST": f"http://localhost:{port}"},
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        try:
            api = ApiClient(f"http://127.0.0.1:{app_port}")
            for _ in range(40):
                try:
                    api.call("/health")
                    break
                except (urllib.error.URLError, OSError):
                    time.sleep(0.3)

            result = api.call(
                "/api/assess",
                "POST",
                {"use_case_id": "uc_credit_briefing", "service_id": "corporate_aggregate_mcp"},
            )
            self.assertFalse(result["allowed"])
            self.assertTrue(result["fail_closed"])
            self.assertIn("FAIL CLOSED", result["overall"]["reason"])
            # The evaluated input survives the failure, for the audit trail.
            self.assertIn("agent", result["opa_input"])
        finally:
            server.terminate()
            try:
                server.wait(timeout=10)
            except subprocess.TimeoutExpired:
                server.kill()


if __name__ == "__main__":
    unittest.main(verbosity=2)
