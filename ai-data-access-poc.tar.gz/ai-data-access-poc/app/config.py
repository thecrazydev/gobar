"""Configuration and path resolution.

Every path is resolved from ``__file__`` rather than the process working
directory, so the app runs correctly regardless of where it is launched from.
There is exactly one definition of each path; nothing re-derives them inline.
"""

from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

POLICY_DIR = ROOT / "policy"
POLICY_FILE = POLICY_DIR / "access.rego"
STATIC_DIR = ROOT / "static"
TEMPLATE_DIR = ROOT / "templates"
BIN_DIR = ROOT / "bin"

# OPA server. The policy is uploaded here at startup and queried per decision.
OPA_HOST = os.environ.get("OPA_HOST", "http://localhost:8181")
OPA_POLICY_ID = "poc_access"
OPA_PACKAGE_PATH = "poc/access"

OPA_DECISION_URL = f"{OPA_HOST}/v1/data/{OPA_PACKAGE_PATH}/decision"
OPA_POLICY_URL = f"{OPA_HOST}/v1/policies/{OPA_POLICY_ID}"
OPA_HEALTH_URL = f"{OPA_HOST}/health"

# Decisions must fail fast; the gateway converts a timeout into a denial.
OPA_TIMEOUT_SECONDS = float(os.environ.get("OPA_TIMEOUT_SECONDS", "2.0"))

# SSE keepalive so idle proxies do not drop the event stream.
SSE_HEARTBEAT_SECONDS = 20.0

APP_TITLE = "AI-Ready Data Access"
APP_VERSION = "1.0.0"
