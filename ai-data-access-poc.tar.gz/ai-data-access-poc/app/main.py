"""One ASGI application serving both halves of the POC.

    /            management UI  — the five registries and the policy
    /runtime     runtime console — the agent, the journey, the audit log

Both read and write the same registries, which is what makes the second demo
scenario possible: change use-case metadata in the management UI and the next
agent run is decided differently, with no change to the agent or the policy.

Built on Starlette (the ASGI framework FastAPI itself is built on) with pydantic
for request validation, so the dependency set is starlette + uvicorn + pydantic.
"""

from __future__ import annotations

import asyncio
import json
import logging
import uuid
from contextlib import asynccontextmanager
from typing import Any

from pydantic import ValidationError
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import FileResponse, JSONResponse, StreamingResponse
from starlette.routing import Mount, Route
from starlette.staticfiles import StaticFiles

from . import agent as agent_service
from . import decision_log, events, gateway, mcp_server, opa_client
from .config import APP_TITLE, APP_VERSION, STATIC_DIR, TEMPLATE_DIR
from .models import AssessRequest, ChatRequest, MetadataPatch
from .registries import store

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s  %(levelname)-7s %(name)s: %(message)s"
)
logger = logging.getLogger("poc")


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------


async def _parse(request: Request, model: type) -> Any:
    """Validate a JSON body against a pydantic model, or raise _BadRequest."""
    try:
        payload = await request.json()
    except (ValueError, json.JSONDecodeError) as exc:
        raise _BadRequest("request body must be valid JSON") from exc
    try:
        return model(**payload)
    except ValidationError as exc:
        raise _BadRequest(exc.errors(include_url=False)) from exc
    except TypeError as exc:
        raise _BadRequest(str(exc)) from exc


class _BadRequest(Exception):
    def __init__(self, detail: Any) -> None:
        self.detail = detail
        super().__init__(str(detail))


def _error(status: int, detail: Any) -> JSONResponse:
    return JSONResponse({"detail": detail}, status_code=status)


# -----------------------------------------------------------------------------
# Pages
# -----------------------------------------------------------------------------


async def management_ui(request: Request) -> FileResponse:
    return FileResponse(TEMPLATE_DIR / "manage.html")


async def runtime_console(request: Request) -> FileResponse:
    return FileResponse(TEMPLATE_DIR / "runtime.html")


async def health(request: Request) -> JSONResponse:
    return JSONResponse(
        {
            "status": "ok",
            "version": APP_VERSION,
            "opa_reachable": await opa_client.is_healthy(),
            "registry_revision": store.revision,
            "sse_subscribers": events.subscriber_count(),
        }
    )


# -----------------------------------------------------------------------------
# Registries — the join between the management UI and the runtime
# -----------------------------------------------------------------------------


async def get_metadata(request: Request) -> JSONResponse:
    return JSONResponse(store.snapshot())


async def patch_metadata(request: Request) -> JSONResponse:
    kind = request.path_params["kind"]
    record_id = request.path_params["record_id"]
    try:
        patch = await _parse(request, MetadataPatch)
    except _BadRequest as exc:
        return _error(400, exc.detail)

    try:
        outcome = store.update(kind, record_id, patch.changes)
    except KeyError as exc:
        return _error(404, str(exc))
    except ValidationError as exc:
        return _error(422, exc.errors(include_url=False))
    except Exception as exc:  # noqa: BLE001 - surface any coercion failure as 422
        return _error(422, str(exc))

    description = store.describe_change(outcome["change"])
    logger.info("metadata change: %s", description)

    # Tell every open runtime console that the ground truth moved.
    events.publish(
        f"meta-{outcome['revision']}",
        "metadata_changed",
        {
            "kind": kind,
            "record_id": record_id,
            "label": outcome["change"]["label"],
            "description": description,
            "diff": outcome["change"]["diff"],
            "revision": outcome["revision"],
        },
    )
    return JSONResponse(outcome)


async def reset_metadata(request: Request) -> JSONResponse:
    store.reset()
    events.publish(
        "meta-reset",
        "metadata_changed",
        {
            "kind": "all",
            "record_id": "*",
            "label": "All registries",
            "description": "Registries reset to seeded values",
            "diff": {},
            "revision": store.revision,
        },
    )
    return JSONResponse(store.snapshot())


# -----------------------------------------------------------------------------
# Decisions
# -----------------------------------------------------------------------------


async def assess(request: Request) -> JSONResponse:
    """Dry run: evaluate a use case against a service, release nothing."""
    try:
        body = await _parse(request, AssessRequest)
    except _BadRequest as exc:
        return _error(400, exc.detail)

    decision = await gateway.assess(store, body.use_case_id, body.service_id, body.action)
    metadata = decision["decision_metadata"]
    return JSONResponse(
        {
            "allowed": decision["allow_access"],
            "policy_version": decision["policy_version"],
            "approval_path": decision.get("approval_path", ""),
            "controls": decision.get("controls", []),
            "overall": metadata.get("overall", {}),
            "dimensions": {k: v for k, v in metadata.items() if k != "overall"},
            "fail_closed": decision.get("fail_closed", False),
            "opa_input": decision.get("opa_input", {}),
            "opa_output": decision.get("opa_output", {}),
            "registry_revision": store.revision,
        }
    )


async def get_policy(request: Request) -> JSONResponse:
    try:
        return JSONResponse({"policy": opa_client.read_policy_source()})
    except FileNotFoundError as exc:
        return _error(404, str(exc))


async def get_decisions(request: Request) -> JSONResponse:
    try:
        limit = int(request.query_params.get("limit", 50))
    except ValueError:
        limit = 50
    return JSONResponse(
        {"summary": decision_log.summary(), "records": decision_log.recent(limit)}
    )


async def get_decision(request: Request) -> JSONResponse:
    correlation_id = request.path_params["correlation_id"]
    records = decision_log.by_correlation_id(correlation_id)
    if not records:
        return _error(404, "no decisions for that correlation id")
    return JSONResponse({"records": records})


# -----------------------------------------------------------------------------
# Runtime: agent turns and the event stream
# -----------------------------------------------------------------------------


async def _run_turn(prompt: str, use_case_id: str, correlation_id: str) -> None:
    events.publish(correlation_id, "agent_start", {"prompt": prompt, "use_case_id": use_case_id})
    try:
        answer = await agent_service.run(
            store, prompt=prompt, correlation_id=correlation_id, use_case_id=use_case_id
        )
        events.publish(correlation_id, "agent_done", {"response": answer})
    except Exception as exc:  # noqa: BLE001 - never leave the console hanging
        logger.exception("agent turn failed")
        events.publish(correlation_id, "agent_error", {"message": str(exc)})


async def chat(request: Request) -> JSONResponse:
    """Start a turn. The answer arrives over the event stream."""
    try:
        body = await _parse(request, ChatRequest)
    except _BadRequest as exc:
        return _error(400, exc.detail)

    if body.use_case_id not in store.use_cases:
        return _error(404, f"unknown use case '{body.use_case_id}'")

    correlation_id = f"req-{uuid.uuid4().hex[:8]}"
    asyncio.create_task(_run_turn(body.prompt, body.use_case_id, correlation_id))
    return JSONResponse({"status": "triggered", "correlation_id": correlation_id})


async def reset_runtime(request: Request) -> JSONResponse:
    decision_log.clear()
    events.publish("reset", "demo_reset", {})
    return JSONResponse({"status": "reset"})


async def event_stream(request: Request) -> StreamingResponse:
    return StreamingResponse(
        events.subscribe(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


async def mcp_datasets(request: Request) -> JSONResponse:
    return JSONResponse({"datasets": mcp_server.available_datasets()})


# -----------------------------------------------------------------------------
# Application
# -----------------------------------------------------------------------------


@asynccontextmanager
async def lifespan(app: Starlette):
    # Upload the policy, retrying while OPA finishes booting.
    for attempt in range(1, 9):
        if await opa_client.is_healthy() and await opa_client.upload_policy():
            break
        logger.info("waiting for OPA (attempt %d)", attempt)
        await asyncio.sleep(1.0)
    else:
        logger.error(
            "OPA was not reachable at startup. The app will serve, but every "
            "decision will fail closed until OPA is available."
        )
    yield


routes = [
    Route("/", management_ui),
    Route("/runtime", runtime_console),
    Route("/health", health),
    Route("/api/metadata", get_metadata),
    Route("/api/metadata/reset", reset_metadata, methods=["POST"]),
    Route("/api/metadata/{kind}/{record_id}", patch_metadata, methods=["PATCH"]),
    Route("/api/assess", assess, methods=["POST"]),
    Route("/api/policy", get_policy),
    Route("/api/decisions", get_decisions),
    Route("/api/decisions/{correlation_id}", get_decision),
    Route("/api/chat", chat, methods=["POST"]),
    Route("/api/reset", reset_runtime, methods=["POST"]),
    Route("/api/events", event_stream),
    Route("/api/mcp/datasets", mcp_datasets),
    Mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static"),
]

app = Starlette(routes=routes, lifespan=lifespan)
app.title = APP_TITLE
app.version = APP_VERSION
