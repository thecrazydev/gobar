"""The only module that talks to OPA.

OPA runs as a long-lived server. The Rego on disk is the source of truth and is
uploaded at startup; a decision that finds no policy loaded re-uploads once and
retries, so a restarted OPA heals itself rather than failing every request.

Fail-closed discipline: OPA unreachable, erroring, timing out, returning an
unparseable body, or holding no policy all converge on the same structured
denial that the console renders exactly like a real policy denial. The only
tell is ``fail_closed`` and the policy version — and unlike the source
prototype, the fail-closed response still carries the input that was evaluated,
because that is precisely what an auditor needs to see.

Transport is the standard library. OPA is a local process, so there is no proxy
or TLS to negotiate, and the blocking call is handed to a worker thread.
"""

from __future__ import annotations

import json
import logging
import urllib.error
import urllib.request
from typing import Any

import anyio.to_thread

from .config import (
    OPA_DECISION_URL,
    OPA_HEALTH_URL,
    OPA_POLICY_URL,
    OPA_TIMEOUT_SECONDS,
    POLICY_FILE,
)

logger = logging.getLogger(__name__)

_DIMENSIONS = (
    "ai_access",
    "data_residency",
    "pii_processing",
    "processing_purpose",
    "jurisdiction_sanction",
    "banking_secrecy",
    "privacy_lawful_basis",
)


class OpaUnavailable(Exception):
    """Raised internally when OPA cannot be reached or refuses a request."""


# -----------------------------------------------------------------------------
# Blocking primitives (run off the event loop)
# -----------------------------------------------------------------------------


def _request(
    url: str,
    *,
    method: str = "GET",
    body: bytes | None = None,
    content_type: str | None = None,
    timeout: float = 5.0,
) -> tuple[int, bytes]:
    request = urllib.request.Request(url, data=body, method=method)
    if content_type:
        request.add_header("Content-Type", content_type)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return response.status, response.read()
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read()
    except (urllib.error.URLError, OSError, TimeoutError) as exc:
        raise OpaUnavailable(str(exc)) from exc


async def _arequest(*args: Any, **kwargs: Any) -> tuple[int, bytes]:
    return await anyio.to_thread.run_sync(
        lambda: _request(*args, **kwargs)  # noqa: PLW0108
    )


# -----------------------------------------------------------------------------
# Public surface
# -----------------------------------------------------------------------------


def fail_closed(reason: str, opa_input: dict[str, Any] | None = None) -> dict[str, Any]:
    """A denial shaped exactly like a real policy denial."""
    detail = f"FAIL CLOSED: {reason}"
    return {
        "allow_access": False,
        "policy_version": "unavailable (FAIL_CLOSED)",
        "decision_metadata": {
            **{d: {"status": "FAILED", "reason": detail} for d in _DIMENSIONS},
            "overall": {"status": "DENIED", "reason": detail},
        },
        "controls": ["Audit logging"],
        "approval_path": "Blocked — policy engine unavailable",
        "opa_input": opa_input or {},
        "opa_output": {},
        "fail_closed": True,
    }


def read_policy_source() -> str:
    if not POLICY_FILE.is_file():
        raise FileNotFoundError(f"policy file missing at {POLICY_FILE}")
    return POLICY_FILE.read_text(encoding="utf-8")


async def is_healthy() -> bool:
    try:
        status, _ = await _arequest(OPA_HEALTH_URL, timeout=2.0)
    except OpaUnavailable:
        return False
    return status == 200


async def upload_policy() -> bool:
    """Push the on-disk Rego into OPA. Returns True on success."""
    try:
        source = read_policy_source()
    except FileNotFoundError as exc:
        logger.error("%s", exc)
        return False

    try:
        status, body = await _arequest(
            OPA_POLICY_URL,
            method="PUT",
            body=source.encode("utf-8"),
            content_type="text/plain",
            timeout=10.0,
        )
    except OpaUnavailable as exc:
        logger.warning("policy upload failed: %s", exc)
        return False

    if status != 200:
        logger.error("OPA rejected the policy (%s): %s", status, body.decode("utf-8", "replace"))
        return False

    logger.info("policy uploaded to OPA")
    return True


async def _query(opa_input: dict[str, Any]) -> dict[str, Any] | None:
    """One decision round-trip. Returns the result object, or None."""
    payload = json.dumps({"input": opa_input}).encode("utf-8")
    status, body = await _arequest(
        OPA_DECISION_URL,
        method="POST",
        body=payload,
        content_type="application/json",
        timeout=OPA_TIMEOUT_SECONDS,
    )
    if status != 200:
        raise OpaUnavailable(f"HTTP {status}")
    try:
        return json.loads(body).get("result")
    except (ValueError, AttributeError) as exc:
        raise OpaUnavailable("malformed response body") from exc


async def evaluate(opa_input: dict[str, Any]) -> dict[str, Any]:
    """Ask OPA for a decision. Never raises; denies instead."""
    try:
        result = await _query(opa_input)
    except OpaUnavailable as exc:
        return fail_closed(f"Policy decision engine is unavailable ({exc}).", opa_input)

    if not result:
        # Policy is probably not loaded. Re-upload once, then retry.
        logger.warning("empty OPA result; re-uploading policy and retrying")
        if await upload_policy():
            try:
                result = await _query(opa_input)
            except OpaUnavailable:
                result = None

    if not result:
        return fail_closed(
            "Policy package 'poc.access' is not loaded or failed to compile.", opa_input
        )

    metadata = result.get("decision_metadata") or {}
    if "overall" not in metadata:
        return fail_closed("Policy returned no overall verdict.", opa_input)

    return {
        "allow_access": bool(result.get("allow_access", False)),
        # Reported by the policy itself, never asserted by this client.
        "policy_version": result.get("policy_version", "unknown"),
        "decision_metadata": metadata,
        "controls": result.get("controls", []),
        "approval_path": result.get("approval_path", ""),
        "opa_input": opa_input,
        "opa_output": result,
        "fail_closed": False,
    }
