"""The five registries, held in memory.

This module is the join between the management UI and the runtime. The gateway
resolves every decision from here, and the management UI writes here — which is
what makes "edit metadata, re-run the agent, watch the decision change" work.

In-memory means edits live for the lifetime of the process and a restart
re-seeds. ``revision`` increments on every change so clients can tell whether
what they are looking at is current.
"""

from __future__ import annotations

import copy
from datetime import datetime, timezone
from typing import Any, Iterable

from .models import Agent, Dataset, McpService, PolicyRules, UseCase

KINDS = ("agents", "use_cases", "datasets", "services", "policy")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _seed_agents() -> dict[str, Agent]:
    return {
        "briefing_agent_01": Agent(
            id="briefing_agent_01",
            name="Corporate Credit Briefing Agent",
            owner="Credit Risk Engineering",
            processing_location="UK",
            can_process_pii=False,
            permitted_actions=["read", "aggregate"],
        ),
        "lux_review_agent_02": Agent(
            id="lux_review_agent_02",
            name="Luxembourg Entity Review Agent",
            owner="Regulatory Reporting",
            processing_location="Luxembourg",
            can_process_pii=True,
            permitted_actions=["read"],
        ),
    }


def _seed_use_cases() -> dict[str, UseCase]:
    return {
        "uc_credit_briefing": UseCase(
            id="uc_credit_briefing",
            name="Corporate Credit Exposure Briefing",
            owner="Credit Risk Front Office",
            agent_id="briefing_agent_01",
            purpose="client_briefing",
            user_role="Credit Risk Analyst",
            data_regions=["UK"],
            lawful_basis="Legitimate interest - credit risk management",
            retention_period="12 months",
        ),
        "uc_lux_entity_review": UseCase(
            id="uc_lux_entity_review",
            name="Luxembourg Entity Regulatory Review",
            owner="Regulatory Reporting",
            agent_id="lux_review_agent_02",
            purpose="risk_evaluation",
            user_role="Regulatory Analyst",
            data_regions=["Luxembourg"],
            lawful_basis="Legal obligation - regulatory reporting",
            retention_period="7 years",
        ),
    }


def _seed_datasets() -> dict[str, Dataset]:
    return {
        "ds_aggregate_exposure": Dataset(
            id="ds_aggregate_exposure",
            name="UK Corporate Aggregate Exposure",
            owner="Credit Risk Data Office",
            data_jurisdiction="UK",
            pii_classification="none",
            contains_client_data=False,
            identity_type="not_applicable",
            ai_access_permitted=True,
        ),
        "ds_client_pii_exposure": Dataset(
            id="ds_client_pii_exposure",
            name="UK Corporate Client Detail (Restricted PII)",
            owner="Credit Risk Data Office",
            data_jurisdiction="UK",
            pii_classification="restricted_pii",
            contains_client_data=True,
            identity_type="true_identity",
            ai_access_permitted=True,
        ),
        "ds_anonymised_exposure": Dataset(
            id="ds_anonymised_exposure",
            name="UK Corporate Anonymised Exposure",
            owner="Credit Risk Data Office",
            data_jurisdiction="UK",
            pii_classification="none",
            contains_client_data=True,
            identity_type="internal_ids_only",
            ai_access_permitted=True,
        ),
        "ds_us_exposure": Dataset(
            id="ds_us_exposure",
            name="US Corporate Credit Exposure",
            owner="Americas Risk Data",
            data_jurisdiction="US",
            pii_classification="none",
            contains_client_data=False,
            identity_type="not_applicable",
            ai_access_permitted=True,
        ),
        "ds_lux_client_exposure": Dataset(
            id="ds_lux_client_exposure",
            name="Luxembourg Client Exposure Detail",
            owner="Luxembourg Data Office",
            data_jurisdiction="Luxembourg",
            pii_classification="restricted_pii",
            contains_client_data=True,
            identity_type="true_identity",
            employee_only_access=False,
            ai_access_permitted=True,
        ),
    }


def _seed_services() -> dict[str, McpService]:
    return {
        "corporate_aggregate_mcp": McpService(
            id="corporate_aggregate_mcp",
            name="UK Corporate Aggregate Exposure",
            owner="Credit Risk Data Office",
            description="Regional and sector aggregates of corporate credit exposure. No client identifiers.",
            jurisdiction="UK",
            permitted_processing_purposes=["client_briefing", "risk_evaluation"],
            dataset_id="ds_aggregate_exposure",
        ),
        "corporate_pii_mcp": McpService(
            id="corporate_pii_mcp",
            name="UK Corporate Client Detail",
            owner="Credit Risk Data Office",
            description="Client-level exposure including names and contact details. Restricted PII.",
            jurisdiction="UK",
            permitted_processing_purposes=["client_briefing", "risk_evaluation"],
            dataset_id="ds_client_pii_exposure",
        ),
        "corporate_anonymised_mcp": McpService(
            id="corporate_anonymised_mcp",
            name="UK Corporate Anonymised Exposure",
            owner="Credit Risk Data Office",
            description="Client exposure by anonymised identifier and sector. Safe alternative to client detail.",
            jurisdiction="UK",
            permitted_processing_purposes=["client_briefing", "risk_evaluation"],
            dataset_id="ds_anonymised_exposure",
        ),
        "us_corporate_mcp": McpService(
            id="us_corporate_mcp",
            name="US Corporate Credit Risk",
            owner="Americas Risk Data",
            description="Americas corporate credit risk analytics. Subject to US residency requirements.",
            jurisdiction="US",
            permitted_processing_purposes=["client_briefing", "risk_evaluation"],
            dataset_id="ds_us_exposure",
        ),
        "lux_client_mcp": McpService(
            id="lux_client_mcp",
            name="Luxembourg Client Exposure",
            owner="Luxembourg Data Office",
            description="Luxembourg booked client exposure detail. Subject to Banking Secrecy.",
            jurisdiction="Luxembourg",
            permitted_processing_purposes=["client_briefing", "risk_evaluation"],
            dataset_id="ds_lux_client_exposure",
        ),
    }


def _seed_policy() -> PolicyRules:
    return PolicyRules(
        id="default",
        owner="Group Data Policy",
        restricted_jurisdictions=["Iran", "North Korea", "Syria"],
        banking_secrecy_jurisdictions=["Luxembourg"],
    )


class RegistryStore:
    """All five registries plus a change log."""

    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self.agents = _seed_agents()
        self.use_cases = _seed_use_cases()
        self.datasets = _seed_datasets()
        self.services = _seed_services()
        self.policy = _seed_policy()
        self.revision = 1
        self.changes: list[dict[str, Any]] = []

    # -- reads ---------------------------------------------------------------

    def snapshot(self) -> dict[str, Any]:
        return {
            "revision": self.revision,
            "agents": [a.model_dump() for a in self.agents.values()],
            "use_cases": [u.model_dump() for u in self.use_cases.values()],
            "datasets": [d.model_dump() for d in self.datasets.values()],
            "services": [s.model_dump() for s in self.services.values()],
            "policy": self.policy.model_dump(),
            "changes": list(reversed(self.changes[-25:])),
        }

    def _collection(self, kind: str) -> dict[str, Any]:
        mapping = {
            "agents": self.agents,
            "use_cases": self.use_cases,
            "datasets": self.datasets,
            "services": self.services,
        }
        if kind not in mapping:
            raise KeyError(f"unknown registry '{kind}'")
        return mapping[kind]

    def resolve_for_decision(
        self, use_case_id: str, service_id: str
    ) -> tuple[UseCase, Agent, McpService, Dataset]:
        """Resolve the records a decision needs, or raise KeyError."""
        use_case = self.use_cases.get(use_case_id)
        if use_case is None:
            raise KeyError(f"use case '{use_case_id}' is not registered")

        agent = self.agents.get(use_case.agent_id)
        if agent is None:
            raise KeyError(f"agent '{use_case.agent_id}' is not registered")

        service = self.services.get(service_id)
        if service is None:
            raise KeyError(f"MCP service '{service_id}' is not registered")

        dataset = self.datasets.get(service.dataset_id)
        if dataset is None:
            raise KeyError(f"dataset '{service.dataset_id}' is not registered")

        return use_case, agent, service, dataset

    def discoverable_services(self) -> list[dict[str, str]]:
        """The catalogue an agent is allowed to see.

        Discovery is deliberately unfiltered: an agent can see that a service
        exists and may request it. Whether it gets the data is decided at the
        gateway, which is where enforcement belongs.
        """
        return [
            {"id": s.id, "name": s.name, "description": s.description}
            for s in self.services.values()
        ]

    # -- writes --------------------------------------------------------------

    def update(self, kind: str, record_id: str, changes: dict[str, Any]) -> dict[str, Any]:
        """Apply a partial update, returning a description of what changed."""
        if kind == "policy":
            current = self.policy
            if record_id not in ("default", self.policy.id):
                raise KeyError(f"unknown policy record '{record_id}'")
            updated = PolicyRules(**{**current.model_dump(), **changes})
            before = current.model_dump()
            self.policy = updated
            after = updated.model_dump()
            label = "Policy rules"
        else:
            collection = self._collection(kind)
            current = collection.get(record_id)
            if current is None:
                raise KeyError(f"'{record_id}' is not in registry '{kind}'")
            model_type = type(current)
            before = current.model_dump()
            updated = model_type(**{**before, **changes})
            collection[record_id] = updated
            after = updated.model_dump()
            label = after.get("name", record_id)

        diff = {
            field: {"from": before.get(field), "to": after.get(field)}
            for field in changes
            if before.get(field) != after.get(field)
        }

        self.revision += 1
        entry = {
            "revision": self.revision,
            "timestamp": _now(),
            "kind": kind,
            "record_id": record_id,
            "label": label,
            "diff": diff,
        }
        self.changes.append(entry)
        return {"record": after, "change": entry, "revision": self.revision}

    def describe_change(self, entry: dict[str, Any]) -> str:
        if not entry["diff"]:
            return f"{entry['label']} saved with no effective change"
        parts = [
            f"{field}: {_fmt(v['from'])} → {_fmt(v['to'])}"
            for field, v in entry["diff"].items()
        ]
        return f"{entry['label']} updated ({'; '.join(parts)})"


def _fmt(value: Any) -> str:
    if isinstance(value, bool):
        return "yes" if value else "no"
    if isinstance(value, (list, tuple)):
        return ", ".join(str(v) for v in value) if value else "(none)"
    if value in (None, ""):
        return "(empty)"
    return str(value)


def deep_copy_registries(store: RegistryStore) -> dict[str, Any]:
    return copy.deepcopy(store.snapshot())


# Single process-wide instance.
store = RegistryStore()


def iter_kinds() -> Iterable[str]:
    return KINDS
