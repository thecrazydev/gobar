"""The policy gateway — the single enforcement point.

The technical architecture puts a gateway between the agent and the data
supplier's MCP server, and routes every tool call through it:

    2  agent asks the gateway to call a tool
    3  gateway asks the decision engine, using metadata from the registries
    4  engine decides, the decision is logged, the gateway is told
    5  gateway tells the MCP server to call the tool
    6  MCP server returns data to the gateway
    7  gateway returns data to the agent

Enforcement lives here rather than inside a tool implementation, so a new tool
cannot be added that forgets to check. The agent never sees the attributes the
decision is made on: it names a service, and the gateway resolves identity,
purpose, data classification and policy configuration server-side.
"""

from __future__ import annotations

import logging
from typing import Any

from . import decision_log, events, mcp_server, opa_client
from .registries import RegistryStore

logger = logging.getLogger(__name__)


def build_policy_input(
    store: RegistryStore, use_case_id: str, service_id: str, action: str
) -> dict[str, Any]:
    """Assemble the OPA input from all five registries."""
    use_case, agent, service, dataset = store.resolve_for_decision(use_case_id, service_id)
    return {
        "action": action,
        "agent": agent.model_dump(),
        "use_case": use_case.model_dump(),
        "service": service.model_dump(),
        "dataset": dataset.model_dump(),
        "policy": store.policy.model_dump(),
    }


async def assess(
    store: RegistryStore,
    use_case_id: str,
    service_id: str,
    action: str = "read",
) -> dict[str, Any]:
    """Evaluate a pairing without releasing data. Used by the management UI."""
    try:
        opa_input = build_policy_input(store, use_case_id, service_id, action)
    except KeyError as exc:
        return opa_client.fail_closed(str(exc))
    return await opa_client.evaluate(opa_input)


async def request_tool_access(
    store: RegistryStore,
    *,
    correlation_id: str,
    use_case_id: str,
    service_id: str,
    action: str = "read",
) -> dict[str, Any]:
    """The full gated path: decide, log, and release data only if allowed."""
    events.publish(
        correlation_id,
        "connection_request",
        {"service_id": service_id, "use_case_id": use_case_id, "action": action},
    )

    # --- resolve registry metadata -----------------------------------------
    try:
        use_case, agent, service, dataset = store.resolve_for_decision(use_case_id, service_id)
    except KeyError as exc:
        decision = opa_client.fail_closed(str(exc))
        events.publish(correlation_id, "checkpoint_failed", {"reason": str(exc)})
        decision_log.record(
            correlation_id=correlation_id,
            agent_id="unknown",
            use_case_id=use_case_id,
            service_id=service_id,
            dataset_id="unknown",
            action=action,
            decision=decision,
        )
        return {"status": "error", "reason": str(exc), "decision": decision}

    opa_input = build_policy_input(store, use_case_id, service_id, action)

    events.publish(
        correlation_id,
        "checkpoint_start",
        {
            "agent": agent.model_dump(),
            "use_case": use_case.model_dump(),
            "service": service.model_dump(),
            "dataset": dataset.model_dump(),
            "policy": store.policy.model_dump(),
            "registry_revision": store.revision,
        },
    )

    # --- ask the decision engine -------------------------------------------
    decision = await opa_client.evaluate(opa_input)
    metadata = decision["decision_metadata"]
    overall = metadata.get("overall", {})

    events.publish(
        correlation_id,
        "checkpoint_result",
        {
            "status": overall.get("status", "DENIED"),
            "reason": overall.get("reason", ""),
            "dimensions": {k: v for k, v in metadata.items() if k != "overall"},
            "controls": decision.get("controls", []),
            "approval_path": decision.get("approval_path", ""),
            "policy_version": decision["policy_version"],
            "opa_input": decision.get("opa_input", {}),
            "opa_output": decision.get("opa_output", {}),
            "fail_closed": decision.get("fail_closed", False),
            "registry_revision": store.revision,
        },
    )

    # --- deny ---------------------------------------------------------------
    if not decision["allow_access"]:
        failed = [
            name
            for name, verdict in metadata.items()
            if name != "overall" and verdict.get("status") == "FAILED"
        ]
        events.publish(
            correlation_id,
            "access_denied",
            {
                "service_id": service_id,
                "dataset_id": dataset.id,
                "reason": overall.get("reason", ""),
                "failed_dimensions": failed,
                "approval_path": decision.get("approval_path", ""),
            },
        )
        decision_log.record(
            correlation_id=correlation_id,
            agent_id=agent.id,
            use_case_id=use_case.id,
            service_id=service.id,
            dataset_id=dataset.id,
            action=action,
            decision=decision,
        )
        return {
            "status": "denied",
            "reason": overall.get("reason", ""),
            "failed_dimensions": failed,
            "approval_path": decision.get("approval_path", ""),
            "policy_version": decision["policy_version"],
            "decision": decision,
            "service": service.model_dump(),
            "dataset": dataset.model_dump(),
        }

    # --- allow: the gateway, not the agent, calls the MCP server ------------
    try:
        rows = mcp_server.fetch(dataset.id)
    except KeyError as exc:
        events.publish(correlation_id, "checkpoint_failed", {"reason": str(exc)})
        decision_log.record(
            correlation_id=correlation_id,
            agent_id=agent.id,
            use_case_id=use_case.id,
            service_id=service.id,
            dataset_id=dataset.id,
            action=action,
            decision=decision,
        )
        return {"status": "error", "reason": str(exc), "decision": decision}

    events.publish(
        correlation_id,
        "data_released",
        {
            "service_id": service.id,
            "dataset_id": dataset.id,
            "record_count": len(rows),
            "controls": decision.get("controls", []),
            "preview": rows[:2],
        },
    )

    decision_log.record(
        correlation_id=correlation_id,
        agent_id=agent.id,
        use_case_id=use_case.id,
        service_id=service.id,
        dataset_id=dataset.id,
        action=action,
        decision=decision,
        record_count=len(rows),
    )

    return {
        "status": "allowed",
        "data": rows,
        "policy_version": decision["policy_version"],
        "controls": decision.get("controls", []),
        "approval_path": decision.get("approval_path", ""),
        "decision": decision,
        "service": service.model_dump(),
        "dataset": dataset.model_dump(),
    }


def discover(store: RegistryStore, correlation_id: str, use_case_id: str) -> dict[str, Any]:
    """Catalogue lookup. Visibility is not access; the gate is at fetch time."""
    use_case = store.use_cases.get(use_case_id)
    purpose = use_case.purpose if use_case else "unknown"

    events.publish(correlation_id, "discovery_started", {"purpose": purpose})
    candidates = store.discoverable_services()
    events.publish(
        correlation_id,
        "discovery_candidates_found",
        {"count": len(candidates), "candidates": candidates},
    )
    return {"count": len(candidates), "services": candidates}
