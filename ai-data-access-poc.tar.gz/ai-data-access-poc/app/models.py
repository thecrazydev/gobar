"""The common metadata model.

The conceptual design has three parties independently codifying the
access-relevant aspects of their own artefacts, once, into a shared model:

    data owners      -> Dataset        (residency, AI access, PII flag)
    policy owners    -> PolicyRules    (policy id, privacy and retention rules)
    use-case owners  -> UseCase        (agent, purpose, user role)

The technical architecture adds two more registries that the decision engine
reads from: the agent registry (Agent) and the MCP / tool registry (McpService).

Every field here is either displayed in the management UI or consumed by the
policy. There are no fields the policy ignores.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

PiiClassification = Literal["none", "restricted_pii"]
IdentityType = Literal["true_identity", "internal_ids_only", "not_applicable"]


class Agent(BaseModel):
    """Agent registry entry — who is asking."""

    id: str
    name: str
    owner: str
    processing_location: str = Field(description="Where the agent executes")
    can_process_pii: bool = False
    permitted_actions: list[str] = Field(default_factory=lambda: ["read"])


class UseCase(BaseModel):
    """Use-case registry entry — why they are asking."""

    id: str
    name: str
    owner: str
    agent_id: str
    purpose: str
    user_role: str
    data_regions: list[str] = Field(
        default_factory=list,
        description="Jurisdictions this use case intends to analyse data in",
    )
    lawful_basis: str = ""
    retention_period: str = ""


class Dataset(BaseModel):
    """Data catalogue entry — what is being asked for."""

    id: str
    name: str
    owner: str
    data_jurisdiction: str
    pii_classification: PiiClassification = "none"
    contains_client_data: bool = False
    identity_type: IdentityType = "not_applicable"
    employee_only_access: bool = False
    ai_access_permitted: bool = True


class McpService(BaseModel):
    """MCP / tool registry entry — the server that would serve the data."""

    id: str
    name: str
    owner: str
    description: str
    jurisdiction: str
    permitted_processing_purposes: list[str] = Field(default_factory=list)
    dataset_id: str


class PolicyRules(BaseModel):
    """Policy rule registry entry — the configurable inputs to the Rego."""

    id: str = "default"
    owner: str
    restricted_jurisdictions: list[str] = Field(default_factory=list)
    banking_secrecy_jurisdictions: list[str] = Field(default_factory=list)


class DimensionVerdict(BaseModel):
    status: Literal["PASSED", "FAILED"]
    reason: str


class PolicyDecision(BaseModel):
    """What the decision engine returns, and what the log stores."""

    allow_access: bool
    policy_version: str
    decision_metadata: dict[str, DimensionVerdict]
    controls: list[str] = Field(default_factory=list)
    approval_path: str = ""
    opa_input: dict[str, Any] = Field(default_factory=dict)
    opa_output: dict[str, Any] = Field(default_factory=dict)
    fail_closed: bool = False


class DecisionRecord(BaseModel):
    """One row of the decision log."""

    correlation_id: str
    timestamp: str
    agent_id: str
    use_case_id: str
    service_id: str
    dataset_id: str
    action: str
    allowed: bool
    policy_version: str
    approval_path: str
    reason: str
    failed_dimensions: list[str] = Field(default_factory=list)
    controls: list[str] = Field(default_factory=list)
    record_count: int = 0
    fail_closed: bool = False
    opa_input: dict[str, Any] = Field(default_factory=dict)
    opa_output: dict[str, Any] = Field(default_factory=dict)


class ChatRequest(BaseModel):
    prompt: str
    use_case_id: str = "uc_credit_briefing"


class MetadataPatch(BaseModel):
    """A partial update applied to one registry record from the management UI."""

    changes: dict[str, Any]


class AssessRequest(BaseModel):
    """Dry-run assessment: evaluate a pairing without releasing any data."""

    use_case_id: str
    service_id: str
    action: str = "read"
