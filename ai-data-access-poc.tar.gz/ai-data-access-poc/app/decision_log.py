"""The decision log.

POC Full lists logging as a required layer in its own right, separate from the
live event stream. Every gateway decision — allowed, denied or failed closed —
lands here keyed by correlation id, with the exact OPA input and output that
produced it.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from .models import DecisionRecord

_MAX_RECORDS = 500

_records: list[DecisionRecord] = []


def record(
    *,
    correlation_id: str,
    agent_id: str,
    use_case_id: str,
    service_id: str,
    dataset_id: str,
    action: str,
    decision: dict[str, Any],
    record_count: int = 0,
) -> DecisionRecord:
    metadata = decision.get("decision_metadata", {})
    failed = [
        name
        for name, verdict in metadata.items()
        if name != "overall" and verdict.get("status") == "FAILED"
    ]

    entry = DecisionRecord(
        correlation_id=correlation_id,
        timestamp=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        agent_id=agent_id,
        use_case_id=use_case_id,
        service_id=service_id,
        dataset_id=dataset_id,
        action=action,
        allowed=bool(decision.get("allow_access")),
        policy_version=decision.get("policy_version", "unknown"),
        approval_path=decision.get("approval_path", ""),
        reason=metadata.get("overall", {}).get("reason", ""),
        failed_dimensions=failed,
        controls=decision.get("controls", []),
        record_count=record_count,
        fail_closed=bool(decision.get("fail_closed")),
        opa_input=decision.get("opa_input", {}),
        opa_output=decision.get("opa_output", {}),
    )

    _records.append(entry)
    del _records[:-_MAX_RECORDS]
    return entry


def recent(limit: int = 50) -> list[dict[str, Any]]:
    return [r.model_dump() for r in reversed(_records[-limit:])]


def by_correlation_id(correlation_id: str) -> list[dict[str, Any]]:
    return [r.model_dump() for r in _records if r.correlation_id == correlation_id]


def summary() -> dict[str, int]:
    return {
        "total": len(_records),
        "allowed": sum(1 for r in _records if r.allowed),
        "denied": sum(1 for r in _records if not r.allowed),
        "fail_closed": sum(1 for r in _records if r.fail_closed),
    }


def clear() -> None:
    _records.clear()
