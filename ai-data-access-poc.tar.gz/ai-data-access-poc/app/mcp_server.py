"""Mocked MCP servers — the data supplier side.

Payloads live here, keyed by dataset id, and deliberately nowhere near the data
catalogue. In the source prototype the mock rows sat inside the same structure
as the access-control attributes, which would not survive contact with a real
data source. Here the catalogue describes data and this module returns it, and
only the gateway may call it.

All figures are invented for demonstration.
"""

from __future__ import annotations

from typing import Any

_PAYLOADS: dict[str, list[dict[str, Any]]] = {
    "ds_aggregate_exposure": [
        {"country": "UK", "industry": "Financial Services", "exposure_m": 1240.5, "risk_level": "Medium"},
        {"country": "UK", "industry": "Energy & Utilities", "exposure_m": 880.0, "risk_level": "High"},
        {"country": "UK", "industry": "Manufacturing", "exposure_m": 610.2, "risk_level": "Medium"},
        {"country": "UK", "industry": "Retail", "exposure_m": 395.4, "risk_level": "Low"},
        {"country": "UK", "industry": "Transport & Logistics", "exposure_m": 285.1, "risk_level": "Medium"},
    ],
    "ds_client_pii_exposure": [
        {"client_name": "Northgate Industrials Ltd", "contact": "treasury@northgate-ind.example", "exposure_increase_m": 48.2},
        {"client_name": "Calder Energy Group plc", "contact": "finance@calder-energy.example", "exposure_increase_m": 41.7},
        {"client_name": "Rowan Freight Holdings", "contact": "cfo@rowanfreight.example", "exposure_increase_m": 33.9},
        {"client_name": "Bellhaven Retail Group", "contact": "ir@bellhaven.example", "exposure_increase_m": 27.4},
        {"client_name": "Tamar Chemicals Ltd", "contact": "accounts@tamarchem.example", "exposure_increase_m": 22.1},
    ],
    "ds_anonymised_exposure": [
        {"anonymised_id": "ANON-C-4471", "sector": "Manufacturing", "exposure_band": "40-50m", "region": "North England"},
        {"anonymised_id": "ANON-C-2208", "sector": "Energy & Utilities", "exposure_band": "40-50m", "region": "Scotland"},
        {"anonymised_id": "ANON-C-9013", "sector": "Transport & Logistics", "exposure_band": "30-40m", "region": "Midlands"},
        {"anonymised_id": "ANON-C-6655", "sector": "Retail", "exposure_band": "20-30m", "region": "South East"},
        {"anonymised_id": "ANON-C-3382", "sector": "Chemicals", "exposure_band": "20-30m", "region": "South West"},
    ],
    "ds_us_exposure": [
        {"country": "US", "industry": "Retail", "exposure_m": 280.4, "risk_level": "Medium"},
        {"country": "US", "industry": "Technology", "exposure_m": 512.8, "risk_level": "Low"},
    ],
    "ds_lux_client_exposure": [
        {"client_name": "Ardenne Holdings S.A.", "booking_entity": "Luxembourg", "exposure_m": 96.3},
        {"client_name": "Moselle Capital S.à r.l.", "booking_entity": "Luxembourg", "exposure_m": 74.8},
        {"client_name": "Clervaux Investments S.A.", "booking_entity": "Luxembourg", "exposure_m": 58.1},
    ],
}


def fetch(dataset_id: str) -> list[dict[str, Any]]:
    """Query the dataset. Called only after the gateway has allowed access."""
    if dataset_id not in _PAYLOADS:
        raise KeyError(f"no data available for dataset '{dataset_id}'")
    return [dict(row) for row in _PAYLOADS[dataset_id]]


def available_datasets() -> list[str]:
    return sorted(_PAYLOADS)
