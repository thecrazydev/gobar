"""Server-sent event fan-out.

The runtime console renders the request journey from this stream. The agent and
the gateway publish into it without importing anything web-related: they call
``publish``, and the web layer owns the transport.

Two things the source prototype lacked and this adds: a heartbeat so idle
proxies do not drop the connection, and per-subscriber queues that drop the
oldest event rather than growing without bound if a browser tab stalls.
"""

from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime, timezone
from typing import Any, AsyncIterator

from .config import SSE_HEARTBEAT_SECONDS

logger = logging.getLogger(__name__)

_MAX_QUEUED_PER_CLIENT = 500

_subscribers: list[asyncio.Queue[str]] = []


def _frame(payload: dict[str, Any]) -> str:
    return f"data: {json.dumps(payload)}\n\n"


def publish(correlation_id: str, event_type: str, payload: dict[str, Any] | None = None) -> None:
    """Broadcast one event to every connected console."""
    message = _frame(
        {
            "correlation_id": correlation_id,
            "event_type": event_type,
            "timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "payload": payload or {},
        }
    )
    logger.info("event %s [%s]", event_type, correlation_id)
    for queue in list(_subscribers):
        if queue.full():
            try:
                queue.get_nowait()
            except asyncio.QueueEmpty:
                pass
        try:
            queue.put_nowait(message)
        except asyncio.QueueFull:
            logger.warning("dropping event for a saturated subscriber")


async def subscribe() -> AsyncIterator[str]:
    """Yield SSE frames until the client disconnects."""
    queue: asyncio.Queue[str] = asyncio.Queue(maxsize=_MAX_QUEUED_PER_CLIENT)
    _subscribers.append(queue)
    try:
        yield _frame(
            {
                "correlation_id": "system",
                "event_type": "connected",
                "payload": {"subscribers": len(_subscribers)},
            }
        )
        while True:
            try:
                yield await asyncio.wait_for(queue.get(), timeout=SSE_HEARTBEAT_SECONDS)
            except asyncio.TimeoutError:
                # Comment frame: keeps the connection warm, ignored by EventSource.
                yield ": keepalive\n\n"
    finally:
        if queue in _subscribers:
            _subscribers.remove(queue)


def subscriber_count() -> int:
    return len(_subscribers)
