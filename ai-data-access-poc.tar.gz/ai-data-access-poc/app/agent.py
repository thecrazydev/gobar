"""The simulated agent.

Deterministic by design: the same prompt always produces the same tool calls,
so a demo cannot wander. What it is *not* is faked — every turn performs real
discovery, makes a real gateway call, and gets a real OPA decision. Only the
natural-language wrapping is scripted.

Responses are rendered from the rows the gateway actually released, never from
hardcoded tables, so the narrative cannot drift away from the data.
"""

from __future__ import annotations

import logging
from typing import Any

from . import events, gateway
from .registries import RegistryStore

logger = logging.getLogger(__name__)

MODEL_LABEL = "Deterministic policy-briefing agent"

# Prompt routing. Order matters: the first matching intent wins.
_INTENTS: list[tuple[str, tuple[str, ...]]] = [
    ("discover", ("what mcp", "which mcp", "what servers", "which servers", "what tools",
                  "which tools", "what data is available", "what is available",
                  "available servers", "available tools", "discover")),
    ("anonymised", ("anonymis", "anonymiz", "safe alternative", "i agree", "i accept",
                    "proceed with the anon", "masked")),
    ("pii", ("name", "contact", "client detail", "detailed client", "who are the clients",
             "identif", "pii")),
    ("luxembourg", ("luxembourg", "lux ")),
    ("us", ("us corporate", "united states", "americas", "us credit", "us exposure")),
    ("aggregate", ("exposure", "briefing", "credit", "aggregate", "by industry", "by country")),
]

_SERVICE_FOR_INTENT = {
    "aggregate": "corporate_aggregate_mcp",
    "pii": "corporate_pii_mcp",
    "anonymised": "corporate_anonymised_mcp",
    "us": "us_corporate_mcp",
    "luxembourg": "lux_client_mcp",
}

_COLUMN_LABELS = {
    "country": "Country",
    "industry": "Industry",
    "exposure_m": "Exposure (£m)",
    "risk_level": "Risk",
    "client_name": "Client",
    "contact": "Contact",
    "exposure_increase_m": "Exposure increase (£m)",
    "anonymised_id": "Anonymised ID",
    "sector": "Sector",
    "exposure_band": "Exposure band",
    "region": "Region",
    "booking_entity": "Booking entity",
}

_DIMENSION_LABELS = {
    "ai_access": "AI access permission",
    "data_residency": "Data residency",
    "pii_processing": "PII processing",
    "processing_purpose": "Processing purpose",
    "jurisdiction_sanction": "Restricted jurisdiction",
    "banking_secrecy": "Banking secrecy",
    "privacy_lawful_basis": "Privacy lawful basis",
}

_HELP = (
    "I can brief you on corporate credit exposure, with every data request "
    "routed through the policy gateway.\n\n"
    "Try:\n"
    "- *What MCP servers are available?*\n"
    "- *Prepare a briefing on corporate credit exposure by industry and country.*\n"
    "- *Add the names and contact details of the largest exposure increases.*\n"
    "- *Use the anonymised client exposure instead.*"
)


def classify(prompt: str) -> str:
    lowered = prompt.lower()
    for intent, triggers in _INTENTS:
        if any(trigger in lowered for trigger in triggers):
            return intent
    return "help"


def _render_table(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return "*No records were returned.*"
    columns = list(rows[0])
    header = "| " + " | ".join(_COLUMN_LABELS.get(c, c) for c in columns) + " |"
    divider = "| " + " | ".join("---" for _ in columns) + " |"
    body = [
        "| " + " | ".join(str(row.get(c, "")) for c in columns) + " |"
        for row in rows
    ]
    return "\n".join([header, divider, *body])


def _alternative_for(service_id: str, store: RegistryStore) -> dict[str, Any] | None:
    """Find a registered service whose dataset carries no restricted PII."""
    if service_id == "corporate_pii_mcp":
        candidate = store.services.get("corporate_anonymised_mcp")
        if candidate is not None:
            return candidate.model_dump()
    return None


def _denial_narrative(result: dict[str, Any], store: RegistryStore, service_id: str) -> str:
    failed = result.get("failed_dimensions", [])
    labels = [_DIMENSION_LABELS.get(d, d) for d in failed]
    service = result.get("service", {})
    dataset = result.get("dataset", {})
    decision_meta = result.get("decision", {}).get("decision_metadata", {})

    lines = [
        f"### Request blocked at the policy gateway",
        "",
        f"I asked the gateway for **{service.get('name', service_id)}** "
        f"(dataset `{dataset.get('id', 'unknown')}`). The policy decision engine denied it "
        f"before any data left the MCP server.",
        "",
        f"**Failed:** {', '.join(labels) if labels else 'policy evaluation'}",
        "",
    ]

    for dimension in failed:
        reason = decision_meta.get(dimension, {}).get("reason", "")
        if reason:
            lines.append(f"- **{_DIMENSION_LABELS.get(dimension, dimension)}** — {reason}")

    approval = result.get("approval_path")
    if approval:
        lines += ["", f"**Approval route:** {approval}"]

    alternative = _alternative_for(service_id, store)
    if alternative:
        lines += [
            "",
            f"There is a compliant alternative registered: **{alternative['name']}** — "
            f"{alternative['description']}",
            "",
            "Say *use the anonymised client exposure instead* and I will request that one.",
        ]

    lines += ["", f"*Zero records were released. Policy {result.get('policy_version', 'unknown')}.*"]
    return "\n".join(lines)


def _allow_narrative(result: dict[str, Any], intent: str) -> str:
    service = result.get("service", {})
    dataset = result.get("dataset", {})
    rows = result.get("data", [])
    controls = result.get("controls", [])

    headings = {
        "aggregate": "Corporate credit exposure — aggregate view",
        "anonymised": "Corporate client exposure — anonymised",
        "pii": "Corporate client detail",
        "us": "US corporate credit exposure",
        "luxembourg": "Luxembourg client exposure",
    }

    lines = [
        f"### {headings.get(intent, service.get('name', 'Requested data'))}",
        "",
        f"The gateway approved access to **{service.get('name', '')}** "
        f"(dataset `{dataset.get('id', '')}`) and released {len(rows)} records.",
        "",
        _render_table(rows),
    ]

    if controls:
        lines += ["", f"**Controls applied:** {', '.join(controls)}"]
    lines += ["", f"*Policy {result.get('policy_version', 'unknown')}.*"]
    return "\n".join(lines)


async def run(
    store: RegistryStore,
    *,
    prompt: str,
    correlation_id: str,
    use_case_id: str,
) -> str:
    """Handle one turn. Publishes journey events as it goes."""
    events.publish(correlation_id, "agent_thinking", {"model": MODEL_LABEL})

    intent = classify(prompt)
    logger.info("intent=%s prompt=%r", intent, prompt)

    if intent == "help":
        gateway.discover(store, correlation_id, use_case_id)
        return _HELP

    discovery = gateway.discover(store, correlation_id, use_case_id)

    if intent == "discover":
        lines = [
            "### Registered MCP servers",
            "",
            f"The MCP/tool registry lists {discovery['count']} servers I can request:",
            "",
        ]
        lines += [f"- **{s['name']}** — {s['description']}" for s in discovery["services"]]
        lines += [
            "",
            "Seeing a server is not the same as being allowed to use it. Every request "
            "goes through the policy gateway, which decides against the registries at "
            "the moment I ask.",
        ]
        return "\n".join(lines)

    service_id = _SERVICE_FOR_INTENT[intent]
    result = await gateway.request_tool_access(
        store,
        correlation_id=correlation_id,
        use_case_id=use_case_id,
        service_id=service_id,
    )

    if result["status"] == "allowed":
        return _allow_narrative(result, intent)
    if result["status"] == "denied":
        return _denial_narrative(result, store, service_id)

    return (
        "### Request could not be evaluated\n\n"
        f"{result.get('reason', 'Unknown error.')}\n\n"
        "*No data was released. The gateway fails closed.*"
    )
